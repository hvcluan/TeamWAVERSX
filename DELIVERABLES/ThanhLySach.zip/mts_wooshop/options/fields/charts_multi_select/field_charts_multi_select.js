jQuery(document).ready(function($){
	jQuery('select.nhpopts-charts_multi_select').select2({
		
	});
});

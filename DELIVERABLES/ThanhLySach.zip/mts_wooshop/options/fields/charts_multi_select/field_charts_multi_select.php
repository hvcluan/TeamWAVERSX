<?php
class NHP_Options_charts_multi_select extends NHP_Options{	
	
	/**
	 * Field Constructor.
	 *
	 * Required - must call the parent constructor, then assign field and value to vars, and obviously call the render field function
	 *
	 * @since NHP_Options 1.0.1
	*/
	function __construct($field = array(), $value ='', $parent){
		
		parent::__construct($parent->sections, $parent->args, $parent->extra_tabs);
		$this->field = $field;
		$this->value = $value;
		//$this->render();
		
	}//function
	
	
	
	/**
	 * Field Render Function.
	 *
	 * Takes the vars and outputs the HTML for the field in the settings
	 *
	 * @since NHP_Options 1.0.1
	*/
	function render(){
		
		$class = (isset($this->field['class']))?$this->field['class']:'';
		
		echo '<select id="'.$this->field['id'].'" name="'.$this->args['opt_name'].'['.$this->field['id'].'][]" class="nhpopts-charts_multi_select '.$class.'" multiple="multiple" style="width: 100%; max-width: 240px;" data-placeholder="'.__( 'Select charts', 'wooshop' ).'">';
		
		$charts_query = array(
			'posts_per_page' => -1,
			'post_status' => array('publish'),
			'post_type' => 'mts_size_chart',
			'order' => 'ASC',
			'orderby' => 'title',
			'suppress_filters' => false,
		);
		$charts = get_posts( $charts_query );

		foreach ( $charts as $chart ) {
			$post_title = $chart->post_title;
			$id = $chart->ID;

			$selected = (is_array($this->value) && in_array($id, $this->value))?' selected="selected"':'';
			echo '<option value="'.$id.'"'.$selected.'>'.$post_title.'</option>';
		}

		echo '</select>';
		
		echo (isset($this->field['desc']) && !empty($this->field['desc']))?'<br/><span class="description">'.$this->field['desc'].'</span>':'';
		
	}//function
	
	/**
	 * Enqueue Function.
	 *
	 * If this field requires any scripts, or css define this function and register/enqueue the scripts/css
	 *
	 * @since NHP_Options 1.0
	*/
	function enqueue(){
		
		wp_enqueue_script(
			'select2', 
			NHP_OPTIONS_URL.'js/select2.min.js', 
			array('jquery'),
			MTS_THEME_VERSION,
			true
		);
		wp_enqueue_script(
			'nhp-opts-field-charts_multi_select-js', 
			NHP_OPTIONS_URL.'fields/charts_multi_select/field_charts_multi_select.js', 
			array('jquery', 'select2'),
			MTS_THEME_VERSION,
			true
		);
		wp_enqueue_style(
			'select2', 
			NHP_OPTIONS_URL.'css/select2.css', 
			array(),
			MTS_THEME_VERSION,
			'all'
		);

		
	}//function
}//class
?>
jQuery(document).ready(function(){
	
	/*
	 *
	 * NHP_Options_date function
	 * Adds datepicker js
	 *
	 */
	jQuery('.nhp-opts-datepicker').datepicker();
	
});
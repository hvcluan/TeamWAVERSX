/*
Theme Name: <?php echo $child_name . "\n"; ?>
Version: 1.0
Description: A child theme of <?php echo $parent_name . "\n"; ?>
Template: <?php echo $parent_stylesheet . "\n"; ?>
Text Domain: <?php echo MTS_THEME_NAME . "\n"; ?>
*/

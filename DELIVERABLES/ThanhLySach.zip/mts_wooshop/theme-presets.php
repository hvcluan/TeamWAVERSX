<?php
// make sure to not include translations
$args['presets']['default'] = array(
	'title' => 'Default',
	'demo' => 'http://demo.mythemeshop.com/wooshop/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/default/thumb.jpg',
	'menus' => array( 'primary-menu' => 'Primary Menu', 'footer-menu' => 'Footer Menu', 'mobile' => '' ), // menu location slug => Demo menu name
	'options' => array( 'show_on_front' => 'page', 'page_on_front' => '980', 'page_for_posts' => '817' ),
);

$args['presets']['flowers'] = array(
	'title' => 'Flowers',
	'demo' => 'http://demo.mythemeshop.com/wooshop-flowers/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/flowers/thumb.jpg',
	'menus' => array( 'primary-menu' => 'Primary Menu', 'footer-menu' => '', 'mobile' => '' ), // menu location slug => Demo menu name
	'options' => array( 'show_on_front' => 'page', 'page_on_front' => '7', 'page_for_posts' => '8' ),
);

$args['presets']['medical'] = array(
	'title' => 'Medical',
	'demo' => 'http://demo.mythemeshop.com/wooshop-medical/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/medical/thumb.jpg',
	'menus' => array( 'primary-menu' => 'Primary Menu', 'footer-menu' => '', 'mobile' => '' ), // menu location slug => Demo menu name
	'options' => array( 'show_on_front' => 'page', 'page_on_front' => '91', 'page_for_posts' => '92' ),
);

$args['presets']['theme-shop'] = array(
	'title' => 'Theme Shop',
	'demo' => 'http://demo.mythemeshop.com/wooshop-theme-shop/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/theme-shop/thumb.jpg',
	'menus' => array( 'primary-menu' => 'Primary Menu', 'footer-menu' => '', 'mobile' => '' ), // menu location slug => Demo menu name
	'options' => array( 'show_on_front' => 'page', 'page_on_front' => '192', 'page_for_posts' => '190' ),
);

$args['presets']['sports'] = array(
	'title' => 'Sports',
	'demo' => 'http://demo.mythemeshop.com/wooshop-sports/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/sports/thumb.jpg',
	'menus' => array( 'primary-menu' => '', 'footer-menu' => 'Footer Menu', 'mobile' => '' ), // menu location slug => Demo menu name
	'options' => array( 'show_on_front' => 'page', 'page_on_front' => '165', 'page_for_posts' => '166' ),
);

global $mts_presets;
$mts_presets = $args['presets'];

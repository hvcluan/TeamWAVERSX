<?php
/**
 * Checkout Form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/form-checkout.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

wc_print_notices();

do_action( 'woocommerce_before_checkout_form', $checkout );

// If checkout registration is disabled and not logged in, the user cannot checkout
if ( ! $checkout->enable_signup && ! $checkout->enable_guest_checkout && ! is_user_logged_in() ) {
	echo apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'You must be logged in to checkout.', 'wooshop' ) );
	return;
}
$login_step_visible = true;
$steps = array(
	'login' => 1,
	'billing' => 2,
	'order' => 3,
	'payment' => 4,
);
if ( $checkout->enable_guest_checkout || ! $checkout->enable_signup ) {
	$login_step_visible = false;
	$steps = array(
		'login' => 0,
		'billing' => 1,
		'order' => 2,
		'payment' => 3,
	);
}
?>
<ul id="checkout-progress" class="clearfix">
	<?php if ( !is_user_logged_in() ) { ?>
		<?php if ( $login_step_visible ) { ?>
			<li class="active"><a href="#" data-tab="tab-login-register"><span class="step-number"><?php echo $steps['login']; ?></span><span class="step-title"><?php _e( 'Login', 'wooshop' ); ?></a></span></li>
			<li><a href="#" data-tab="tab-billing-shipping"><span class="step-number"><?php echo $steps['billing']; ?></span><span class="step-title"><?php _e( 'Billing & Shipping', 'wooshop' ); ?></a></span></li>
		<?php } else { ?>
			<li class="active"><a href="#" data-tab="tab-billing-shipping"><span class="step-number"><?php echo $steps['billing']; ?></span><span class="step-title"><?php _e( 'Billing & Shipping', 'wooshop' ); ?></a></span></li>
		<?php } ?>
	<?php } else { ?>
		<?php if ( $login_step_visible ) { ?>
		<li class="disabled"><a href="#" data-tab="tab-login-register"><span class="step-number"><?php echo $steps['login']; ?></span><span class="step-title"><?php _e( 'Login', 'wooshop' ); ?></a></span></li>
		<?php } ?>
		<li class="active"><a href="#" data-tab="tab-billing-shipping"><span class="step-number"><?php echo $steps['billing']; ?></span><span class="step-title"><?php _e( 'Billing & Shipping', 'wooshop' ); ?></a></span></li>
	<?php } ?>
	<li><a href="#" data-tab="tab-review-order"><span class="step-number"><?php echo $steps['order']; ?></span><span class="step-title"><?php _e( 'Review Order', 'wooshop' ); ?></span></a></li>
	<li><a href="#" data-tab="tab-payment-method"><span class="step-number"><?php echo $steps['payment']; ?></span><span class="step-title"><?php _e( 'Make Payment', 'wooshop' ); ?></span></a></li>
</ul>
<div id="checkout-content">
	<?php if ( !is_user_logged_in() && $login_step_visible ) {?>
		<div class="checkout-tab active" id="tab-login-register">
			<?php do_action( 'wooshop_checkout_login_form', $checkout ); ?>
		</div>
	<?php } ?>
	<form name="checkout" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data">

		<?php if ( sizeof( $checkout->checkout_fields ) > 0 ) : ?>

			<div class="checkout-tab<?php if ( is_user_logged_in() || !$login_step_visible ) { echo ' active'; } ?>" id="tab-billing-shipping">
				<?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>

				<div id="customer_details">
					<?php do_action( 'woocommerce_checkout_billing' ); ?>
					<?php do_action( 'woocommerce_checkout_shipping' ); ?>
				</div>

				<?php do_action( 'woocommerce_checkout_after_customer_details' ); ?>
				<a href="#" class="button" data-tab="tab-review-order"><?php _e( 'Continue', 'wooshop' ); ?></a>
			</div>

		<?php endif; ?>

		<div class="checkout-tab" id="tab-review-order">
			<h3 id="order_review_heading"><?php _e( 'Your order', 'wooshop' ); ?></h3>

			<?php do_action( 'woocommerce_checkout_before_order_review' ); ?>

			<div id="order_review" class="woocommerce-checkout-review-order">
				<?php do_action( 'woocommerce_checkout_order_review' ); ?>
			</div>

			<?php do_action( 'woocommerce_checkout_after_order_review' ); ?>
			<a href="#" class="button" data-tab="tab-payment-method"><?php _e( 'Continue', 'wooshop' ); ?></a>
		</div>

		<div class="checkout-tab" id="tab-payment-method">
			<h3><?php _e( 'Make Payment', 'wooshop' ); ?></h3>
			<?php do_action( 'wooshop_checkout_payment_method' ); ?>
		</div>
		

	</form>

	<?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>
</div>

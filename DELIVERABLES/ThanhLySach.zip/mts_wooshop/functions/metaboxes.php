<?php

/**
 * Add a "Sidebar" selection metabox.
 */
function mts_add_sidebar_metabox() {
	$screens = array('post', 'page');
	foreach ($screens as $screen) {
		add_meta_box(
			'mts_sidebar_metabox',
			__('Sidebar', 'wooshop' ),
			'mts_inner_sidebar_metabox',
			$screen,
			'side',
			'high'
		);
	}
}
add_action('add_meta_boxes', 'mts_add_sidebar_metabox');


/**
 * Print the box content.
 * 
 * @param WP_Post $post The object for the current post/page.
 */
function mts_inner_sidebar_metabox($post) {
	global $wp_registered_sidebars;
	
	// Add an nonce field so we can check for it later.
	wp_nonce_field('mts_inner_sidebar_metabox', 'mts_inner_sidebar_metabox_nonce');
	
	/*
	* Use get_post_meta() to retrieve an existing value
	* from the database and use the value for the form.
	*/
	$custom_sidebar = get_post_meta( $post->ID, '_mts_custom_sidebar', true );
	$sidebar_location = get_post_meta( $post->ID, '_mts_sidebar_location', true );

	// Select custom sidebar from dropdown
	echo '<select name="mts_custom_sidebar" id="mts_custom_sidebar" style="margin-bottom: 10px;">';
	echo '<option value="" '.selected('', $custom_sidebar).'>-- '.__('Default', 'wooshop' ).' --</option>';
	
	// Exclude built-in sidebars
	$hidden_sidebars = array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-second', 'footer-second-2', 'footer-second-3', 'footer-second-4', 'widget-header','shop-sidebar', 'product-sidebar', 'homepage-sidebar', 'catalog-ads');	
	
	foreach ($wp_registered_sidebars as $sidebar) {
		if (!in_array($sidebar['id'], $hidden_sidebars)) {
			echo '<option value="'.esc_attr($sidebar['id']).'" '.selected($sidebar['id'], $custom_sidebar, false).'>'.$sidebar['name'].'</option>';
		}
	}
	echo '<option value="mts_nosidebar" '.selected('mts_nosidebar', $custom_sidebar).'>-- '.__('No sidebar --', 'wooshop' ).'</option>';
	echo '</select><br />';
	
	// Select single layout (left/right sidebar)
	echo '<div class="mts_sidebar_location_fields">';
	echo '<label for="mts_sidebar_location_default" style="display: inline-block; margin-right: 20px;"><input type="radio" name="mts_sidebar_location" id="mts_sidebar_location_default" value=""'.checked('', $sidebar_location, false).'>'.__('Default side', 'wooshop' ).'</label>';
	echo '<label for="mts_sidebar_location_left" style="display: inline-block; margin-right: 20px;"><input type="radio" name="mts_sidebar_location" id="mts_sidebar_location_left" value="left"'.checked('left', $sidebar_location, false).'>'.__('Left', 'wooshop' ).'</label>';
	echo '<label for="mts_sidebar_location_right" style="display: inline-block; margin-right: 20px;"><input type="radio" name="mts_sidebar_location" id="mts_sidebar_location_right" value="right"'.checked('right', $sidebar_location, false).'>'.__('Right', 'wooshop' ).'</label>';
	echo '</div>';
	
	?>
	<script type="text/javascript">
		jQuery(document).ready(function($) {
			function mts_toggle_sidebar_location_fields() {
				$('.mts_sidebar_location_fields').toggle(($('#mts_custom_sidebar').val() != 'mts_nosidebar'));
			}
			mts_toggle_sidebar_location_fields();
			$('#mts_custom_sidebar').change(function() {
				mts_toggle_sidebar_location_fields();
			});
		});
	</script>
	<?php
	//debug
	//global $wp_meta_boxes;
}

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 *
 * @return int
 */
function mts_save_custom_sidebar( $post_id ) {
	
	/*
	* We need to verify this came from our screen and with proper authorization,
	* because save_post can be triggered at other times.
	*/
	
	// Check if our nonce is set.
	if ( ! isset( $_POST['mts_inner_sidebar_metabox_nonce'] ) )
	return $post_id;
	
	$nonce = $_POST['mts_inner_sidebar_metabox_nonce'];
	
	// Verify that the nonce is valid.
	if ( ! wp_verify_nonce( $nonce, 'mts_inner_sidebar_metabox' ) )
	  return $post_id;
	
	// If this is an autosave, our form has not been submitted, so we don't want to do anything.
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
	  return $post_id;
	
	// Check the user's permissions.
	if ( 'page' == $_POST['post_type'] ) {
	
	if ( ! current_user_can( 'edit_page', $post_id ) )
		return $post_id;
	
	} else {
	
	if ( ! current_user_can( 'edit_post', $post_id ) )
		return $post_id;
	}
	
	/* OK, its safe for us to save the data now. */
	
	// Sanitize user input.
	$sidebar_name = sanitize_text_field( $_POST['mts_custom_sidebar'] );
	$sidebar_location = sanitize_text_field( $_POST['mts_sidebar_location'] );
	
	// Update the meta field in the database.
	update_post_meta( $post_id, '_mts_custom_sidebar', $sidebar_name );
	update_post_meta( $post_id, '_mts_sidebar_location', $sidebar_location );
}
add_action( 'save_post', 'mts_save_custom_sidebar' );


/**
 * Add "Post Template" selection meta box
 */
function mts_add_posttemplate_metabox() {
	add_meta_box(
		'mts_posttemplate_metabox',
		__('Template', 'wooshop' ),
		'mts_inner_posttemplate_metabox',
		'post',
		'side',
		'high'
	);
}
//add_action('add_meta_boxes', 'mts_add_posttemplate_metabox');


/**
 * Print the box content.
 * 
 * @param WP_Post $post The object for the current post/page.
 */
function mts_inner_posttemplate_metabox($post) {
	
	// Add an nonce field so we can check for it later.
	wp_nonce_field('mts_inner_posttemplate_metabox', 'mts_inner_posttemplate_metabox_nonce');
	
	/*
	* Use get_post_meta() to retrieve an existing value
	* from the database and use the value for the form.
	*/
	$posttemplate = get_post_meta( $post->ID, '_mts_posttemplate', true );

	// Select post template
	echo '<select name="mts_posttemplate" style="margin-bottom: 10px;">';
	echo '<option value="" '.selected('', $posttemplate).'>'.__('Default Post Template', 'wooshop' ).'</option>';
	echo '<option value="parallax" '.selected('parallax', $posttemplate).'>'.__('Parallax Template', 'wooshop' ).'</option>';
	echo '<option value="zoomout" '.selected('zoomout', $posttemplate).'>'.__('Zoom Out Effect Template', 'wooshop' ).'</option>';
	echo '</select><br />';
}

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 *
 * @return int
 */
function mts_save_posttemplate( $post_id ) {
	
	/*
	* We need to verify this came from our screen and with proper authorization,
	* because save_post can be triggered at other times.
	*/
	
	// Check if our nonce is set.
	if ( ! isset( $_POST['mts_inner_posttemplate_metabox_nonce'] ) )
	return $post_id;
	
	$nonce = $_POST['mts_inner_posttemplate_metabox_nonce'];
	
	// Verify that the nonce is valid.
	if ( ! wp_verify_nonce( $nonce, 'mts_inner_posttemplate_metabox' ) )
	  return $post_id;
	
	// If this is an autosave, our form has not been submitted, so we don't want to do anything.
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
	  return $post_id;
	
	// Check the user's permissions.
	if ( 'page' == $_POST['post_type'] ) {
	
	if ( ! current_user_can( 'edit_page', $post_id ) )
		return $post_id;
	
	} else {
	
	if ( ! current_user_can( 'edit_post', $post_id ) )
		return $post_id;
	}
	
	/* OK, its safe for us to save the data now. */
	
	// Sanitize user input.
	$posttemplate = sanitize_text_field( $_POST['mts_posttemplate'] );
	
	// Update the meta field in the database.
	update_post_meta( $post_id, '_mts_posttemplate', $posttemplate );
}
add_action( 'save_post', 'mts_save_posttemplate' );

// Related function: mts_get_posttemplate( $single_template ) in functions.php

/**
 * Add "Page Header Animation" metabox.
 */
function mts_add_postheader_metabox() {
	$screens = array('post', 'page');
	foreach ($screens as $screen) {
		add_meta_box(
			'mts_postheader_metabox',
			__('Header Animation', 'wooshop' ),
			'mts_inner_postheader_metabox',
			$screen,
			'side',
			'high'
		);
	}
}
add_action('add_meta_boxes', 'mts_add_postheader_metabox');


/**
 * Print the box content.
 * 
 * @param WP_Post $post The object for the current post/page.
 */
function mts_inner_postheader_metabox($post) {
	
	// Add an nonce field so we can check for it later.
	wp_nonce_field('mts_inner_postheader_metabox', 'mts_inner_postheader_metabox_nonce');
	
	/*
	* Use get_post_meta() to retrieve an existing value
	* from the database and use the value for the form.
	*/
	$postheader = get_post_meta( $post->ID, '_mts_postheader', true );

	// Select post header effect
	echo '<select name="mts_postheader" style="margin-bottom: 10px;">';
	echo '<option value="" '.selected('', $postheader).'>'.__('None', 'wooshop' ).'</option>';
	echo '<option value="parallax" '.selected('parallax', $postheader).'>'.__('Parallax Effect', 'wooshop' ).'</option>';
	echo '<option value="zoomout" '.selected('zoomout', $postheader).'>'.__('Zoom Out Effect', 'wooshop' ).'</option>';
	echo '</select><br />';
}

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 *
 * @return int
 *
 * @see mts_get_post_header_effect
 */
function mts_save_postheader( $post_id ) {
	
	/*
	* We need to verify this came from our screen and with proper authorization,
	* because save_post can be triggered at other times.
	*/
	
	// Check if our nonce is set.
	if ( ! isset( $_POST['mts_inner_postheader_metabox_nonce'] ) )
	return $post_id;
	
	$nonce = $_POST['mts_inner_postheader_metabox_nonce'];
	
	// Verify that the nonce is valid.
	if ( ! wp_verify_nonce( $nonce, 'mts_inner_postheader_metabox' ) )
	  return $post_id;
	
	// If this is an autosave, our form has not been submitted, so we don't want to do anything.
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
	  return $post_id;
	
	// Check the user's permissions.
	if ( 'page' == $_POST['post_type'] ) {
	
		if ( ! current_user_can( 'edit_page', $post_id ) )
			return $post_id;
	
	} else {
	
		if ( ! current_user_can( 'edit_post', $post_id ) )
			return $post_id;
	}
	
	/* OK, its safe for us to save the data now. */
	
	// Sanitize user input.
	$postheader = sanitize_text_field( $_POST['mts_postheader'] );
	
	// Update the meta field in the database.
	update_post_meta( $post_id, '_mts_postheader', $postheader );
}
add_action( 'save_post', 'mts_save_postheader' );

/**
 * Add "Table" metabox.
 */
function mts_add_chart_metabox() {
	$screens = array('mts_size_chart');
	foreach ($screens as $screen) {
		add_meta_box(
			'mts_chart_metabox',
			__('Table', 'wooshop' ),
			'mts_inner_chart_metabox',
			$screen,
			'normal',
			'high'
		);
	}
}
add_action('add_meta_boxes', 'mts_add_chart_metabox');


/**
 * Print the box content.
 * 
 * @param WP_Post $post The object for the current post/page.
 */
function mts_inner_chart_metabox($post) {
	
	// Add an nonce field so we can check for it later.
	wp_nonce_field('mts_inner_chart_metabox', 'mts_inner_chart_metabox_nonce');
	
	/*
	* Use get_post_meta() to retrieve an existing value
	* from the database and use the value for the form.
	*/
	$table_meta = get_post_meta( $post->ID, '_table_meta', true ) ? get_post_meta( $post->ID, '_table_meta', true ) : '[[""]]';

	$t = json_decode($table_meta);
	?>

	<div id="mts-metabox-table-wrapper">
	    <input id="mts-table-hidden" type="hidden" name="_table_meta" value='<?php echo $table_meta; ?>'>
	    <table id="mts-metabox-table">
	        <thead>
	        <tr>
	            <?php foreach($t[0] as $col): ?>
	                <th>
	                    <input type="button" class="mts-add-col mts-table-button mts-table-button-add" value="+" />
	                    <input type="button" class="mts-del-col mts-table-button mts-table-button-del" value="-" />
	                </th>
	            <?php endforeach; ?>
	            <th></th>
	        </tr>
	        </thead>

	        <tbody>
	        <?php foreach($t as $row): ?>
	            <tr>
	                <?php foreach($row as $col): ?>
	                <td>
	                    <input class="mts-input-table" type="text" value="<?php echo str_replace('"', '&quot;', $col); ?>"/>
	                </td>
	                <?php endforeach; ?>
	                <td class="mts-table-button-container">
	                    <input type="button" class="mts-add-row mts-table-button mts-table-button-add" value="+" />
	                    <input type="button" class="mts-del-row mts-table-button mts-table-button-del" value="-" />
	                </td>
	            </tr>
	        <?php endforeach; ?>

	        </tbody>
	    </table>
	</div>
	<?php
}

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 *
 * @return int
 *
 * @see mts_get_post_header_effect
 */
function mts_save_chart( $post_id ) {
	
	/*
	* We need to verify this came from our screen and with proper authorization,
	* because save_post can be triggered at other times.
	*/
	
	// Check if our nonce is set.
	if ( ! isset( $_POST['mts_inner_chart_metabox_nonce'] ) )
	return $post_id;
	
	$nonce = $_POST['mts_inner_chart_metabox_nonce'];
	
	// Verify that the nonce is valid.
	if ( ! wp_verify_nonce( $nonce, 'mts_inner_chart_metabox' ) )
	  return $post_id;
	
	// If this is an autosave, our form has not been submitted, so we don't want to do anything.
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
	  return $post_id;
	
	// Check the user's permissions.
	if ( 'page' == $_POST['post_type'] ) {
	
		if ( ! current_user_can( 'edit_page', $post_id ) )
			return $post_id;
	
	} else {
	
		if ( ! current_user_can( 'edit_post', $post_id ) )
			return $post_id;
	}
	
	/* OK, its safe for us to save the data now. */
	if ( !empty( $_POST[ '_table_meta' ] ) ) {
        $table_meta = $_POST[ '_table_meta' ];

        update_post_meta( $post_id, '_table_meta', $table_meta );
    }
}
add_action( 'save_post', 'mts_save_chart' );

/**
 * Add "Table" metabox.
 */
function mts_add_chart_popup_metabox() {
	$screens = array('mts_size_chart_popup');
	foreach ($screens as $screen) {
		add_meta_box(
			'mts_chart_popup_metabox',
			__('Size Chart Popup Settings', 'wooshop' ),
			'mts_inner_chart_popup_metabox',
			$screen,
			'normal',
			'high'
		);
	}
}
add_action('add_meta_boxes', 'mts_add_chart_popup_metabox');


/**
 * Print the box content.
 * 
 * @param WP_Post $post The object for the current post/page.
 */
function mts_inner_chart_popup_metabox($post) {
	
	// Add an nonce field so we can check for it later.
	wp_nonce_field('mts_inner_chart_popup_metabox', 'mts_inner_chart_popup_metabox_nonce');
	
	$default_settings = array(
		'link_title' => __('Size Chart', 'wooshop'),
		'charts' => '',
	);
	$settings = get_post_meta( $post->ID, '_chart_popup_settings', true ) ? get_post_meta( $post->ID, '_chart_popup_settings', true ) : $default_settings;

	?>
	<div id="mts-chart-popup-settings">
		<div class="mts-chart-popup-settings-field">
			<label for="chart_popup_settings_link_title"><?php _e( 'Link Title:', 'wooshop' ); ?></label>
			<div class="mts-chart-popup-settings-field-option">
				<input type="text" id="chart_popup_settings_link_title" name="chart_popup_settings[link_title]" value="<?php echo esc_attr( $settings['link_title'] ); ?>">
			</div>
		</div>
		<div class="mts-chart-popup-settings-field">
			<label for="chart_popup_settings_charts"><?php _e( 'Size Charts:', 'wooshop' ); ?></label>
			<div class="mts-chart-popup-settings-field-option">
				<select multiple class="mts-chart-popup-multi-select" name="chart_popup_settings[charts][]" id="chart_popup_settings_charts" style="min-width: 240px;">
					<?php
					$options = mts_get_size_charts_options_array();
					if ( !empty( $settings['charts'] ) ) {
						foreach ( $settings['charts'] as $id ) {
							if ( isset( $options[ $id ] ) ) {
								$name = $options[ $id ];
								unset( $options[ $id ] );
							}
							?>
							<option value="<?php echo esc_attr( $id );?>" selected="selected"><?php echo esc_html( $name ); ?></option>
							<?php
						}
					}

					if ( !empty( $options ) ) {
						foreach ( $options as $id => $name ) {

							$selected =  in_array( $id, $settings['charts'] ) ? ' selected="selected"' : '';
							?>
							<option value="<?php echo esc_attr( $id );?>"<?php echo $selected; ?>><?php echo esc_html( $name ); ?></option>
							<?php
						}
					}
					?>
				</select>
			</div>
		</div>
	</div>
	<?php
}

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 *
 * @return int
 *
 * @see mts_get_post_header_effect
 */
function mts_save_chart_popup( $post_id ) {
	
	/*
	* We need to verify this came from our screen and with proper authorization,
	* because save_post can be triggered at other times.
	*/
	
	// Check if our nonce is set.
	if ( ! isset( $_POST['mts_inner_chart_popup_metabox_nonce'] ) )
	return $post_id;
	
	$nonce = $_POST['mts_inner_chart_popup_metabox_nonce'];
	
	// Verify that the nonce is valid.
	if ( ! wp_verify_nonce( $nonce, 'mts_inner_chart_popup_metabox' ) )
	  return $post_id;
	
	// If this is an autosave, our form has not been submitted, so we don't want to do anything.
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
	  return $post_id;
	
	// Check the user's permissions.
	if ( 'page' == $_POST['post_type'] ) {
	
		if ( ! current_user_can( 'edit_page', $post_id ) )
			return $post_id;
	
	} else {
	
		if ( ! current_user_can( 'edit_post', $post_id ) )
			return $post_id;
	}
	
	/* OK, its safe for us to save the data now. */
	if ( !empty( $_POST[ 'chart_popup_settings' ] ) ) {
        $settings = $_POST[ 'chart_popup_settings' ];

        update_post_meta( $post_id, '_chart_popup_settings', $settings );
    }
}
add_action( 'save_post', 'mts_save_chart_popup' );

add_action( 'admin_enqueue_scripts', 'mts_size_chart_admin_enqueue_scripts' );
function mts_size_chart_admin_enqueue_scripts() {

    $screen = get_current_screen();
    if ( 'mts_size_chart' == $screen->id ) {
		wp_enqueue_style( 'mts_chart_metabox', get_template_directory_uri() . '/css/chart-metabox.css' );
        wp_enqueue_script( 'mts_chart_metabox', get_template_directory_uri() . '/js/chart-metabox.js', array( 'jquery' ), MTS_THEME_VERSION, true );
    }

    if ( 'mts_size_chart_popup' == $screen->id ) {
    	wp_deregister_style('select2');
    	wp_dequeue_style('select2');
    	wp_deregister_script('select2');
    	wp_dequeue_script('select2');
    	wp_enqueue_style(
			'select2', 
			get_template_directory_uri().'/css/select2.css',
			array(),
			MTS_THEME_VERSION,
			'all'
		);
		wp_enqueue_style( 'mts_chart_popup_metabox', get_template_directory_uri() . '/css/chart-popup-metabox.css' );
		wp_enqueue_script(
			'select2', 
			get_template_directory_uri().'/js/select2.min.js',
			array('jquery'),
			MTS_THEME_VERSION,
			true
		);
        wp_enqueue_script( 'mts_chart_popup_metabox', get_template_directory_uri() . '/js/chart-popup-metabox.js', array( 'select2' ), MTS_THEME_VERSION, true );
    }
}

/**
 * Add "Size Chart Popup" metabox.
 */
function mts_add_product_chart_popup_metabox() {
	$screens = array('product');
	foreach ($screens as $screen) {
		add_meta_box(
			'mts_product_chart_popup_metabox',
			__('Size Chart Popup', 'wooshop' ),
			'mts_inner_product_chart_popup_metabox',
			$screen,
			'side',
			'default'
		);
	}
}
add_action('add_meta_boxes', 'mts_add_product_chart_popup_metabox');


/**
 * Print the box content.
 * 
 * @param WP_Post $post The object for the current post/page.
 */
function mts_inner_product_chart_popup_metabox($post) {
	
	// Add an nonce field so we can check for it later.
	wp_nonce_field('mts_inner_product_chart_popup_metabox', 'mts_inner_product_chart_popup_metabox_nonce');
	
	/*
	* Use get_post_meta() to retrieve an existing value
	* from the database and use the value for the form.
	*/
	$product_size_chart_popup = get_post_meta( $post->ID, '_mts_product_size_chart_popup', true ) ? get_post_meta( $post->ID, '_mts_product_size_chart_popup', true ) : '';

	?>
	<p>
	<?php _e( 'Select Size Chart Popup:', 'wooshop' ); ?><br />
	<select id="mts_product_size_chart_popup" name="mts_product_size_chart_popup">
		<?php
		$options = mts_get_size_chart_popups_options_array();
		foreach ( $options as $id => $name ) {
			$selected = $product_size_chart_popup == $id ? ' selected="selected"': '';
	        echo  '<option value="'.$id.'"'.$selected.'>'.$name.'</option>';
		}
		?>
	</select>
	</p>
	<p>
	<strong><?php _e( 'Or', 'wooshop' ); ?></strong>
	</p>
	<?php $disable = get_post_meta( $post->ID, '_mts_product_size_chart_popup_disable', true ); ?>
	<p>
		<label for="mts_product_size_chart_popup_disable">
			<input type="checkbox" name="mts_product_size_chart_popup_disable" id="mts_product_size_chart_popup_disable" <?php checked( $disable, 'yes' ); ?> value="1" />
			<?php _e( 'Disable popups for this product', 'wooshop' ); ?>
		</label>
	</p>
	<?php
}

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 *
 * @return int
 *
 * @see mts_get_post_header_effect
 */
function mts_save_product_chart_popup( $post_id ) {
	
	/*
	* We need to verify this came from our screen and with proper authorization,
	* because save_post can be triggered at other times.
	*/
	
	// Check if our nonce is set.
	if ( ! isset( $_POST['mts_inner_product_chart_popup_metabox_nonce'] ) )
	return $post_id;
	
	$nonce = $_POST['mts_inner_product_chart_popup_metabox_nonce'];
	
	// Verify that the nonce is valid.
	if ( ! wp_verify_nonce( $nonce, 'mts_inner_product_chart_popup_metabox' ) )
	  return $post_id;
	
	// If this is an autosave, our form has not been submitted, so we don't want to do anything.
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
	  return $post_id;
	
	// Check the user's permissions.
	if ( 'page' == $_POST['post_type'] ) {
	
		if ( ! current_user_can( 'edit_page', $post_id ) )
			return $post_id;
	
	} else {
	
		if ( ! current_user_can( 'edit_post', $post_id ) )
			return $post_id;
	}
	
	/* OK, its safe for us to save the data now. */
	if ( !empty( $_POST[ 'mts_product_size_chart_popup' ] ) ) {
        $product_size_chart_popup = $_POST[ 'mts_product_size_chart_popup' ];

        update_post_meta( $post_id, '_mts_product_size_chart_popup', $product_size_chart_popup );
    }

    if ( isset( $_POST['mts_product_size_chart_popup_disable'] ) ) {
		$val = 'yes';
	} else {
		$val = 'no';
	}

	update_post_meta( $post_id, '_mts_product_size_chart_popup_disable', $val );
}
add_action( 'save_post', 'mts_save_product_chart_popup' );

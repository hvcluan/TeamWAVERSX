<?php
/**
 * Template Name: Home Page
 */
$mts_options = get_option(MTS_THEME_NAME);
get_header(); ?>

<div id="page" class="page-home woocommerce">
	<div class="article">
		<div id="content_box">
			<?php $j = 0; if (have_posts()) : while (have_posts()) : the_post();
				if ( !empty( $mts_options['mts_featured_slider'] ) ) { ?>
					<div class="primary-slider-container clearfix loading">
						<div id="home-slider" class="primary-slider">
							<?php if ( !empty( $mts_options['mts_custom_slider'] ) ) { 
								foreach( $mts_options['mts_custom_slider'] as $slide ) : ?>
									<a href="<?php echo esc_url( $slide['mts_custom_slider_link'] ); ?>">
										<?php echo wp_get_attachment_image( $slide['mts_custom_slider_image'], 'wooshop-slider', false, array('title' => '') ); ?>
										<div class="slide-caption">
											<?php if ( !empty( $slide['mts_custom_slider_title'] ) ) { ?>
												<h2 class="slider-product-title" style="color: <?php echo $slide['mts_custom_slider_title_color']; ?>"><?php echo $slide['mts_custom_slider_title']; ?></h2>
											<?php } ?>
											<?php if ( !empty( $slide['mts_custom_slider_heading'] ) ) { ?>
												<h3 class="slider-product-heading" style="color: <?php echo $slide['mts_custom_slider_heading_color']; ?>; background: <?php echo $slide['mts_custom_slider_heading_bg']; ?>"><?php echo $slide['mts_custom_slider_heading']; ?></h3>
											<?php } ?>
											<?php if ( !empty( $slide['mts_custom_slider_subheading'] ) ) { ?>
												<h6 class="slider-product-subheading" style="color: <?php echo $slide['mts_custom_slider_subheading_color']; ?>"><?php echo $slide['mts_custom_slider_subheading']; ?></h6>
											<?php } ?>
											<?php if ( !empty( $slide['mts_custom_slider_button'] ) ) { ?>
												<div class="slider-product-button" style="color: <?php echo $slide['mts_custom_slider_button_color']; ?>; background: <?php echo $slide['mts_custom_slider_button_bg']; ?>"><?php echo $slide['mts_custom_slider_button']; ?></div>
											<?php } ?>
										</div>
									</a>
								<?php endforeach;
							} ?>
						</div><!-- .primary-slider -->
					</div><!-- .primary-slider-container -->
				<?php } ?>

				<?php if ( $mts_options['mts_call_to_action'] ) { ?>
					<div class="call-to-action" style="<?php echo mts_get_background_styles('mts_call_to_action_bg'); echo 'color:'.$mts_options['mts_call_to_action_text_color']; ?>">
						<?php

						if ( !empty( $mts_options['mts_call_to_action_text'] ) ) { ?>
							<div class="call-to-action-text"><?php echo $mts_options['mts_call_to_action_text']; ?></div>
						<?php } ?>

						<?php if ( !empty( $mts_options['mts_call_to_action_button_link'] ) ) { ?>
							<div class="call-to-action-button">
								<a href="<?php echo esc_url( $mts_options['mts_call_to_action_button_link'] ); ?>"><?php echo $mts_options['mts_call_to_action_button_text']; ?></a>
							</div>
					   <?php } ?> 
					</div>
				<?php } ?>

				<?php if ( isset( $mts_options['mts_quare_banners'] ) && ( $mts_options['mts_quare_banners'] == '1') && !empty( $mts_options['mts_quare_banner_images'] ) ) { 

					$mts_square_banner_layout = $mts_options['mts_quare_banners_layout'];
					if ( 'col-3' == $mts_square_banner_layout ) {
						$layout_class = 'col-3';
					} elseif ( 'col-full' == $mts_square_banner_layout ) {
						$layout_class = 'col-full';
					} else { 
						$layout_class = 'col-4';
					} ?>

					<div class="banner-images <?php echo $layout_class; ?>">
						<?php 
						foreach( $mts_options['mts_quare_banner_images'] as $banner ) {
							if ( !empty( $banner['mts_square_banner_image'] ) ) { ?>
								<div class="banner-image">
									<?php if($banner['mts_square_banner_link']) { ?><a href="<?php echo $banner['mts_square_banner_link'];?>"><?php } ?>
									<img src="<?php echo $banner['mts_square_banner_image']; ?>">
									<?php if($banner['mts_square_banner_text']) { ?>
										<h6 class="banner-text" style="<?php echo 'color:'.$banner['mts_square_banner_text_color'].'; background:rgba('.mts_convert_hex_to_rgb($banner['mts_square_banner_text_bg']); ?>, 0.95)"><?php echo $banner['mts_square_banner_text']; ?>
										</h6>
									<?php }
									if($banner['mts_square_banner_link']) { ?></a><?php } ?>
								</div>
							<?php }
						} ?>
					</div>

				<?php } ?>
			<?php endwhile; else: ?>
			<?php endif; ?>
		</div>
	</div>
	<?php get_sidebar(); ?>
<?php get_footer(); ?>
<?php

defined('ABSPATH') or die;

/*
 * 
 * Require the framework class before doing anything else, so we can use the defined urls and dirs
 *
 */
require_once( dirname( __FILE__ ) . '/options/options.php' );

/*
 * 
 * Add support tab
 *
 */
if ( ! defined('MTS_THEME_WHITE_LABEL') || ! MTS_THEME_WHITE_LABEL ) {
	require_once( dirname( __FILE__ ) . '/options/support.php' );
	$mts_options_tab_support = MTS_Options_Tab_Support::get_instance();
}

/*
 * 
 * Custom function for filtering the sections array given by theme, good for child themes to override or add to the sections.
 * Simply include this function in the child themes functions.php file.
 *
 * NOTE: the defined constansts for urls, and dir will NOT be available at this point in a child theme, so you must use
 * get_template_directory_uri() if you want to use any of the built in icons
 *
 */
function add_another_section($sections){
	
	//$sections = array();
	$sections[] = array(
		'title' => __('A Section added by hook', 'wooshop' ),
		'desc' => '<p class="description">' . __('This is a section created by adding a filter to the sections array, great to allow child themes, to add/remove sections from the options.', 'wooshop' ) . '</p>',
		//all the glyphicons are included in the options folder, so you can hook into them, or link to your own custom ones.
		//You dont have to though, leave it blank for default.
		'icon' => trailingslashit(get_template_directory_uri()).'options/img/glyphicons/glyphicons_062_attach.png',
		//Lets leave this as a blank section, no options just some intro text set above.
		'fields' => array()
	);
	
	return $sections;
	
}//function
//add_filter('nhp-opts-sections-twenty_eleven', 'add_another_section');


/*
 * 
 * Custom function for filtering the args array given by theme, good for child themes to override or add to the args array.
 *
 */
function change_framework_args($args){
	
	//$args['dev_mode'] = false;
	
	return $args;
	
}//function
//add_filter('nhp-opts-args-twenty_eleven', 'change_framework_args');

/*
 * This is the meat of creating the optons page
 *
 * Override some of the default values, uncomment the args and change the values
 * - no $args are required, but there there to be over ridden if needed.
 *
 *
 */

function setup_framework_options(){
	$args = array();

	//Set it to dev mode to view the class settings/info in the form - default is false
	$args['dev_mode'] = false;
	//Remove the default stylesheet? make sure you enqueue another one all the page will look whack!
	//$args['stylesheet_override'] = true;

	//Add HTML before the form
	//$args['intro_text'] = __('<p>This is the HTML which can be displayed before the form, it isnt required, but more info is always better. Anything goes in terms of markup here, any HTML.</p>', 'wooshop' );

	if ( ! MTS_THEME_WHITE_LABEL ) {
		//Setup custom links in the footer for share icons
		$args['share_icons']['twitter'] = array(
			'link' => 'http://twitter.com/mythemeshopteam',
			'title' => __( 'Follow Us on Twitter', 'wooshop' ),
			'img' => 'fa fa-twitter-square'
		);
		$args['share_icons']['facebook'] = array(
			'link' => 'http://www.facebook.com/mythemeshop',
			'title' => __( 'Like us on Facebook', 'wooshop' ),
			'img' => 'fa fa-facebook-square'
		);
	}

	//Choose to disable the import/export feature
	//$args['show_import_export'] = false;

	//Choose a custom option name for your theme options, the default is the theme name in lowercase with spaces replaced by underscores
	$args['opt_name'] = MTS_THEME_NAME;

	//Custom menu icon
	//$args['menu_icon'] = '';

	//Custom menu title for options page - default is "Options"
	$args['menu_title'] = __('Theme Options', 'wooshop' );

	//Custom Page Title for options page - default is "Options"
	$args['page_title'] = __('Theme Options', 'wooshop' );

	//Custom page slug for options page (wp-admin/themes.php?page=***) - default is "nhp_theme_options"
	$args['page_slug'] = 'theme_options';

	//Custom page capability - default is set to "manage_options"
	//$args['page_cap'] = 'manage_options';

	//page type - "menu" (adds a top menu section) or "submenu" (adds a submenu) - default is set to "menu"
	//$args['page_type'] = 'submenu';

	//parent menu - default is set to "themes.php" (Appearance)
	//the list of available parent menus is available here: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
	//$args['page_parent'] = 'themes.php';

	//custom page location - default 100 - must be unique or will override other items
	$args['page_position'] = 62;

	//Custom page icon class (used to override the page icon next to heading)
	//$args['page_icon'] = 'icon-themes';

	if ( ! MTS_THEME_WHITE_LABEL ) {
		//Set ANY custom page help tabs - displayed using the new help tab API, show in order of definition
		$args['help_tabs'][] = array(
			'id' => 'nhp-opts-1',
			'title' => __('Support', 'wooshop' ),
			'content' => '<p>' . sprintf( __('If you are facing any problem with our theme or theme option panel, head over to our %s.', 'wooshop' ), '<a href="http://community.mythemeshop.com/">'. __( 'Support Forums', 'wooshop' ) . '</a>' ) . '</p>'
		);
		$args['help_tabs'][] = array(
			'id' => 'nhp-opts-2',
			'title' => __('Earn Money', 'wooshop' ),
			'content' => '<p>' . sprintf( __('Earn 70%% commision on every sale by refering your friends and readers. Join our %s.', 'wooshop' ), '<a href="http://mythemeshop.com/affiliate-program/">' . __( 'Affiliate Program', 'wooshop' ) . '</a>' ) . '</p>'
		);
	}

	//Set the Help Sidebar for the options page - no sidebar by default										
	//$args['help_sidebar'] = __('<p>This is the sidebar content, HTML is allowed.</p>', 'wooshop' );

	$mts_patterns = array(
		'nobg' => array('img' => NHP_OPTIONS_URL.'img/patterns/nobg.png'),
		'blackimg' => array('img' => NHP_OPTIONS_URL.'img/patterns/blackimg.jpg'),
		'whiteimg' => array('img' => NHP_OPTIONS_URL.'img/patterns/whiteimg.jpg'),
		'lightimg' => array('img' => NHP_OPTIONS_URL.'img/patterns/lightimg.jpg'),
		'pattern0' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern0.png'),
		'pattern1' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern1.png'),
		'pattern2' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern2.png'),
		'pattern3' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern3.png'),
		'pattern4' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern4.png'),
		'pattern5' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern5.png'),
		'pattern6' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern6.png'),
		'pattern7' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern7.png'),
		'pattern8' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern8.png'),
		'pattern9' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern9.png'),
		'pattern10' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern10.png'),
		'pattern11' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern11.png'),
		'pattern12' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern12.png'),
		'pattern13' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern13.png'),
		'pattern14' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern14.png'),
		'pattern15' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern15.png'),
		'pattern16' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern16.png'),
		'pattern17' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern17.png'),
		'pattern18' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern18.png'),
		'pattern19' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern19.png'),
		'pattern20' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern20.png'),
		'pattern21' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern21.png'),
		'pattern22' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern22.png'),
		'pattern23' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern23.png'),
		'pattern24' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern24.png'),
		'pattern25' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern25.png'),
		'pattern26' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern26.png'),
		'pattern27' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern27.png'),
		'pattern28' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern28.png'),
		'pattern29' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern29.png'),
		'pattern30' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern30.png'),
		'pattern31' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern31.png'),
		'pattern32' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern32.png'),
		'pattern33' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern33.png'),
		'pattern34' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern34.png'),
		'pattern35' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern35.png'),
		'pattern36' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern36.png'),
		'pattern37' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern37.png'),
		'hbg' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg.png'),
		'hbg2' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg2.png'),
		'hbg3' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg3.png'),
		'hbg4' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg4.png'),
		'hbg5' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg5.png'),
		'hbg6' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg6.png'),
		'hbg7' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg7.png'),
		'hbg8' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg8.png'),
		'hbg9' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg9.png'),
		'hbg10' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg10.png'),
		'hbg11' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg11.png'),
		'hbg12' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg12.png'),
		'hbg13' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg13.png'),
		'hbg14' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg14.png'),
		'hbg15' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg15.png'),
		'hbg16' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg16.png'),
		'hbg17' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg17.png'),
		'hbg18' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg18.png'),
		'hbg19' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg19.png'),
		'hbg20' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg20.png'),
		'hbg21' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg21.png'),
		'hbg22' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg22.png'),
		'hbg23' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg23.png'),
		'hbg24' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg24.png'),
		'hbg25' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg25.png')
	);

	$sections = array();

	$sections[] = array(
		'icon' => 'fa fa-cogs',
		'title' => __('General Settings', 'wooshop' ),
		'desc' => '<p class="description">' . __('This tab contains common setting options which will be applied to the whole theme.', 'wooshop' ) . '</p>',
		'fields' => array(
			array(
				'id' => 'mts_logo',
				'type' => 'upload',
				'title' => __('Logo Image', 'wooshop' ),
				'sub_desc' => __('Upload your logo using the Upload Button or insert image URL.', 'wooshop' ),
				'return' => 'id'
			),
			array(
				'id' => 'mts_favicon',
				'type' => 'upload',
				'title' => __('Favicon', 'wooshop' ),
				'sub_desc' => sprintf( __('Upload a %s image that will represent your website\'s favicon.', 'wooshop' ), '<strong>32 x 32 px</strong>' ),
				'return' => 'id'
			),
			array(
				'id' => 'mts_touch_icon',
				'type' => 'upload',
				'title' => __('Touch icon', 'wooshop' ),
				'sub_desc' => sprintf( __('Upload a %s image that will represent your website\'s touch icon for iOS 2.0+ and Android 2.1+ devices.', 'wooshop' ), '<strong>152 x 152 px</strong>' ),
				'return' => 'id'
			),
			array(
				'id' => 'mts_metro_icon',
				'type' => 'upload',
				'title' => __('Metro icon', 'wooshop' ),
				'sub_desc' => sprintf( __('Upload a %s image that will represent your website\'s IE 10 Metro tile icon.', 'wooshop' ), '<strong>144 x 144 px</strong>' ),
				'return' => 'id'
			),
			array(
				'id' => 'mts_twitter_username',
				'type' => 'text',
				'title' => __('Twitter Username', 'wooshop' ),
				'sub_desc' => __('Enter your Username here.', 'wooshop' ),
			),
			array(
				'id' => 'mts_feedburner',
				'type' => 'text',
				'title' => __('FeedBurner URL', 'wooshop' ),
				'sub_desc' => sprintf( __('Enter your FeedBurner\'s URL here, ex: %s and your main feed (http://example.com/feed) will get redirected to the FeedBurner ID entered here.)', 'wooshop' ), '<strong>http://feeds.feedburner.com/mythemeshop</strong>' ),
				'validate' => 'url'
			),
			array(
				'id' => 'mts_header_code',
				'type' => 'textarea',
				'title' => __('Header Code', 'wooshop' ),
				'sub_desc' => wp_kses( __('Enter the code which you need to place <strong>before closing &lt;/head&gt; tag</strong>. (ex: Google Webmaster Tools verification, Bing Webmaster Center, BuySellAds Script, Alexa verification etc.)', 'wooshop' ), array( 'strong' => array() ) )
			),
			array(
				'id' => 'mts_analytics_code',
				'type' => 'textarea',
				'title' => __('Footer Code', 'wooshop' ),
				'sub_desc' => wp_kses( __('Enter the codes which you need to place in your footer. <strong>(ex: Google Analytics, Clicky, STATCOUNTER, Woopra, Histats, etc.)</strong>.', 'wooshop' ), array( 'strong' => array() ) )
			),
			array(
				'id' => 'mts_pagenavigation_type',
				'type' => 'radio',
				'title' => __('Pagination Type', 'wooshop' ),
				'sub_desc' => __('Select pagination type.', 'wooshop' ),
				'options' => array(
					'0'=> __('Default (Next / Previous)', 'wooshop' ),
					'1' => __('Numbered (1 2 3 4...)', 'wooshop' ),
					'2' => __( 'AJAX (Load More Button)', 'wooshop' ),
					'3' => __( 'AJAX (Auto Infinite Scroll)', 'wooshop' ) 
				),
				'std' => '1'
			),
			array(
				'id' => 'mts_ajax_search',
				'type' => 'button_set',
				'title' => __('AJAX Quick search', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => __('Enable or disable search results appearing instantly below the search form', 'wooshop' ),
				'std' => '0'
			),
			array(
				'id' => 'mts_responsive',
				'type' => 'button_set',
				'title' => __('Responsiveness', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => __('MyThemeShop themes are responsive, which means they adapt to tablet and mobile devices, ensuring that your content is always displayed beautifully no matter what device visitors are using. Enable or disable responsiveness using this option.', 'wooshop' ),
				'std' => '1'
			),
			array(
				'id' => 'mts_rtl',
				'type' => 'button_set',
				'title' => __('Right To Left Language Support', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => __('Enable this option for right-to-left sites.', 'wooshop' ),
				'std' => '0'
			),
		)
	);
	$sections[] = array(
		'icon' => 'fa fa-bolt',
		'title' => __('Performance', 'wooshop' ),
		'desc' => '<p class="description">' . __('This tab contains performance-related options which can help speed up your website.', 'wooshop' ) . '</p>',
		'fields' => array(
			array(
				'id' => 'mts_prefetching',
				'type' => 'button_set',
				'title' => __('Prefetching', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => __('Enable or disable prefetching. If user is on homepage, then single page will load faster and if user is on single page, homepage will load faster in modern browsers.', 'wooshop' ),
				'std' => '0'
			),
			array(
				'id' => 'mts_lazy_load',
				'type' => 'button_set_hide_below',
				'title' => __('Lazy Load', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => __('Delay loading of images outside of viewport, until user scrolls to them.', 'wooshop' ),
				'std' => '0',
				'args' => array('hide' => 2)
				),
				array(
					'id' => 'mts_lazy_load_thumbs',
					'type' => 'button_set',
					'title' => __('Lazy load featured images', 'wooshop' ),
					'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
					'sub_desc' => __('Enable or disable Lazy load of featured images across site.', 'wooshop' ),
					'std' => '0'
				),
				array(
					'id' => 'mts_lazy_load_content',
					'type' => 'button_set',
					'title' => __('Lazy load post content images', 'wooshop' ),
					'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
					'sub_desc' => __('Enable or disable Lazy load of images inside post/page content.', 'wooshop' ),
					'std' => '0'
			),
			array(
				'id' => 'mts_async_js',
				'type' => 'button_set',
				'title' => __('Async JavaScript', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => sprintf( __('Add %s attribute to script tags to improve page download speed.', 'wooshop' ), '<code>async</code>' ),
				'std' => '1',
			),
			array(
				'id' => 'mts_remove_ver_params',
				'type' => 'button_set',
				'title' => __('Remove ver parameters', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => sprintf( __('Remove %s parameter from CSS and JS file calls. It may improve speed in some browsers which do not cache files having the parameter.', 'wooshop' ), '<code>ver</code>' ),
				'std' => '1',
			),
			'cache_message' => array(
				'id' => 'mts_cache_message',
				'type' => 'info',
				'title' => __('Use Cache', 'wooshop' ),
				// Translators: %1$s = popup link to W3 Total Cache, %2$s = popup link to WP Super Cache
				'desc' => sprintf(
					__('A cache plugin can increase page download speed dramatically. We recommend using %1$s or %2$s.', 'wooshop' ),
					'<a href="https://community.mythemeshop.com/tutorials/article/8-make-your-website-load-faster-using-w3-total-cache-plugin/" target="_blank" title="W3 Total Cache">W3 Total Cache</a>',
					'<a href="'.admin_url( 'plugin-install.php?tab=plugin-information&plugin=wp-super-cache&TB_iframe=true&width=772&height=574' ).'" class="thickbox" title="WP Super Cache">WP Super Cache</a>'
				),
			),
		)
	);

	// Hide cache message on multisite or if a chache plugin is active already
	if ( is_multisite() || strstr( join( ';', get_option( 'active_plugins' ) ), 'cache' ) ) {
		unset( $sections[1]['fields']['cache_message'] );
	}

	$sections[] = array(
		'icon' => 'fa fa-adjust',
		'title' => __('Styling Options', 'wooshop' ),
		'desc' => '<p class="description">' . __('Control the visual appearance of your theme, such as colors, layout and patterns, from here.', 'wooshop' ) . '</p>',
		'fields' => array(
			array(
				'id' => 'mts_color_scheme',
				'type' => 'color',
				'title' => __('Primary Color', 'wooshop' ),
				'sub_desc' => __('The theme comes with unlimited color schemes for your <strong>Primary Color</strong> styling.', 'wooshop' ),
				'std' => '#ffb600'
			),
			array(
				'id' => 'mts_second_color_scheme',
				'type' => 'color',
				'title' => __('Secondary Color', 'wooshop' ),
				'sub_desc' => __('The theme comes with unlimited color schemes for your <strong>Secondary Color</strong> styling.', 'wooshop' ),
				'std' => '#f2a595'
			),
			array(
				'id' => 'mts_layout',
				'type' => 'radio_img',
				'title' => __('Blog Layout Style', 'wooshop' ),
				'sub_desc' => wp_kses( __('Choose the <strong>default sidebar position</strong> for your blog. The position of the sidebar for individual posts can be set in the post editor.', 'wooshop' ), array( 'strong' => array() ) ),
				'options' => array(
					'cslayout' => array('img' => NHP_OPTIONS_URL.'img/layouts/cs.png'),
					'sclayout' => array('img' => NHP_OPTIONS_URL.'img/layouts/sc.png')
				),
				'std' => 'cslayout'
			),
			array(
				'id' => 'mts_background',
				'type' => 'background',
				'title' => __('Site Background', 'wooshop' ),
				'sub_desc' => __('Set background color, pattern and image from here. <br />You can also set <strong>Dropdown</strong> and <strong>Floating Navigation</strong> background color from here.', 'wooshop' ),
				'options' => array(
					'color'		 => '',
					'image_pattern' => $mts_patterns,
					'image_upload'  => '',
					'repeat'		=> array(),
					'attachment'	=> array(),
					'position'	=> array(),
					'size'		=> array(),
					'gradient'	=> '',
					'parallax'	=> array(),
				),
				'std' => array(
					'color'		 => '#2d2a32',
					'use'		 => 'pattern',
					'image_pattern' => 'blackimg',
					'image_upload'  => '',
					'repeat'		=> 'repeat',
					'attachment'	=> 'scroll',
					'position'	=> 'left top',
					'size'		=> 'cover',
					'gradient'	=> array('from' => '#ffffff', 'to' => '#000000', 'direction' => 'horizontal' ),
					'parallax'	=> '0',
				)
			),
			array(
				'id' => 'mts_custom_css',
				'type' => 'textarea',
				'title' => __('Custom CSS', 'wooshop' ),
				'sub_desc' => __('You can enter custom CSS code here to further customize your theme. This will override the default CSS used on your site.', 'wooshop' )
			),
			array(
				'id' => 'mts_lightbox',
				'type' => 'button_set',
				'title' => __('Lightbox in Single Posts', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => __('A lightbox is a stylized pop-up that allows your visitors to view larger versions of images without leaving the current page. You can enable or disable the lightbox here.', 'wooshop' ),
				'std' => '0'
			),
		)
	);
	$sections[] = array(
		'icon' => 'fa fa-credit-card',
		'title' => __('Header', 'wooshop' ),
		'desc' => '<p class="description">' . __('From here, you can control the elements of header section.', 'wooshop' ) . '</p>',
		'fields' => array(
			array(
				'id' => 'mts_show_primary_nav',
				'type' => 'button_set_hide_below',
				'title' => __('Show Primary Menu', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => sprintf( __('Use this button to enable %s.', 'wooshop' ), '<strong>' . __( 'Primary Navigation Menu', 'wooshop' ) . '</strong>' ),
				'std' => '1',
				'args' => array('hide' => 2)
			),
			array(
				'id' => 'mts_primary_nav_hover',
				'type' => 'color',
				'title' => __('Primary Menu Hover Color', 'wooshop' ),
				'sub_desc' => __('The theme comes with unlimited color schemes for your <strong>Primary Menu Hover Color</strong> styling.', 'wooshop' ),
				'std' => '#eaebec'
			),
			array(
				'id' => 'mts_sticky_nav',
				'type' => 'button_set',
				'title' => __('Floating Navigation Menu', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => sprintf( __('Use this button to enable %s.', 'wooshop' ), '<strong>' . __('Floating Navigation Menu', 'wooshop' ) . '</strong>' ),
				'std' => '0'
			),
			array(
				'id' => 'mts_header_section2',
				'type' => 'button_set',
				'title' => __('Show Logo', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => wp_kses( __('Use this button to Show or Hide the <strong>Logo</strong> completely.', 'wooshop' ), array( 'strong' => array() ) ),
				'std' => '1'
			),
			array(
				'id' => 'mts_header_search',
				'type' => 'button_set',
				'title' => __('Show Header Search Form', 'wooshop'), 
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => __('Use this button to Show or Hide <strong>Header Search Form</strong>.', 'wooshop'),
				'std' => '1'
			),
			array(
				'id' => 'mts_header_cart',
				'type' => 'button_set_hide_below',
				'title' => __('Show Header Cart Button', 'wooshop'), 
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => __('Use this button to Show or Hide <strong>Header Checkout Button</strong>.', 'wooshop'),
				'std' => '1',
				'args' => array('hide' => 2)
			),
			array(
				'id' => 'mts_header_cart_bg_color',
				'type' => 'color',
				'title' => __('Cart Button Background Color', 'wooshop' ),
				'sub_desc' => __('The theme comes with unlimited color schemes for your <strong>cart button background color</strong> styling.', 'wooshop' ),
				'std' => '#919094'
			),
			array(
				'id' => 'mts_header_cart_color',
				'type' => 'color',
				'title' => __('Cart Button Color', 'wooshop' ),
				'sub_desc' => __('The theme comes with unlimited color schemes for your <strong>cart button color</strong> styling.', 'wooshop' ),
				'std' => '#d2d2d4'
			),
			array(
				'id' => 'mts_header_checkout',
				'type' => 'button_set_hide_below',
				'title' => __('Show Header Checkout Button', 'wooshop'), 
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => __('Use this button to Show or Hide <strong>Header Checkout Button</strong>.', 'wooshop'),
				'std' => '1',
				'args' => array('hide' => 2)
			),
			array(
				'id' => 'mts_header_checkout_bg_color',
				'type' => 'color',
				'title' => __('Checkout Button Background Color', 'wooshop' ),
				'sub_desc' => __('The theme comes with unlimited color schemes for your <strong>checkout button background color</strong> styling.', 'wooshop' ),
				'std' => '#ffb600'
			),
			array(
				'id' => 'mts_header_checkout_color',
				'type' => 'color',
				'title' => __('Checkout Button Color', 'wooshop' ),
				'sub_desc' => __('The theme comes with unlimited color schemes for your <strong>checkout button color</strong> styling.', 'wooshop' ),
				'std' => '#ffffff'
			),
		)
	);
	$sections[] = array(
		'icon' => 'fa fa-table',
		'title' => __('Footer', 'wooshop' ),
		'desc' => '<p class="description">' . __('From here, you can control the elements of Footer section.', 'wooshop' ) . '</p>',
		'fields' => array(
			array(
				'id' => 'mts_first_footer',
				'type' => 'button_set_hide_below',
				'title' => __('Footer WIdegts', 'wooshop' ),
				'sub_desc' => __('Enable or disable footer widgets with this option.', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'std' => '0',
				'args' => array('hide' => 2)
			),
			array(
				'id' => 'mts_first_footer_num',
				'type' => 'button_set',
				'class' => 'green',
				'title' => __('Footer Widget Layout', 'wooshop' ),
				'sub_desc' => wp_kses( __('Choose the number of widget areas in the <strong>first footer</strong>', 'wooshop' ), array( 'strong' => array() ) ),
				'options' => array(
					'3' => __( '3 Widgets', 'wooshop' ),
					'4' => __( '4 Widgets', 'wooshop' ),
				),
				'std' => '3'
			),
			array(
				'id' => 'mts_footer_background',
				'type' => 'background',
				'title' => __('Footer Background', 'wooshop' ),
				'sub_desc' => __('Set footer background color, pattern and image from here.', 'wooshop' ),
				'options' => array(
					'color'		 => '',
					'image_pattern' => $mts_patterns,
					'image_upload'  => '',
					'repeat'		=> array(),
					'attachment'	=> array(),
					'position'	=> array(),
					'size'		=> array(),
					'gradient'	=> '',
					'parallax'	=> array(),
				),
				'std' => array(
					'color'		 => '#2d2a32',
					'use'		 => 'pattern',
					'image_pattern' => 'nobg',
					'image_upload'  => '',
					'repeat'		=> 'repeat',
					'attachment'	=> 'scroll',
					'position'	=> 'left top',
					'size'		=> 'cover',
					'gradient'	=> array('from' => '#ffffff', 'to' => '#000000', 'direction' => 'horizontal' ),
					'parallax'	=> '0',
				)
			),
			array(
				'id' => 'mts_show_footer_nav',
				'type' => 'button_set',
				'title' => __('Footer Navigation', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => __('Enable or disable footer navigation menu', 'wooshop' ),
				'std' => '1'
			),
			array(
				'id' => 'mts_copyrights',
				'type' => 'textarea',
				'title' => __('Copyrights Text', 'wooshop' ),
				'sub_desc' => __( 'You can change or remove our link from footer and use your own custom text.', 'wooshop' ) . ( MTS_THEME_WHITE_LABEL ? '' : wp_kses( __('(You can also use your affiliate link to <strong>earn 70% of sales</strong>. Ex: <a href="https://mythemeshop.com/go/aff/aff" target="_blank">https://mythemeshop.com/?ref=username</a>)', 'wooshop' ), array( 'strong' => array(), 'a' => array( 'href' => array(), 'target' => array() ) ) ) ),
				'std' => MTS_THEME_WHITE_LABEL ? null : sprintf( __( 'Theme by %s', 'wooshop' ), '<a href="http://mythemeshop.com/" rel="nofollow">MyThemeShop</a>' )
			),
			array(
				'id'        => 'mts_accepted_payment_method_icons',
				'type'      => 'group',
				'title'     => __('Accepted Payment Methods Icons', 'wooshop'),
				'sub_desc'  => __('Add accepted payment methods icons in the footer area.', 'wooshop'),
				'groupname' => __('Payment Method Icon', 'wooshop'), // Group name
				'subfields' => array(
					array(
						'id' => 'mts_accepted_payment_method_title',
						'type' => 'text',
						'title' => __('Payment Method', 'wooshop'),
						'sub_desc' => __('Enter the title for this payment method.', 'wooshop')
					),
					array(
						'id' => 'mts_accepted_payment_method_icon',
						'type' => 'icon_select',
						'title' => __('Payment Method Icon', 'wooshop'),
						'sub_desc' => __('Select icon for this payment method.', 'wooshop'),
						'subset' => __( 'Payment Icons', 'wooshop' )
					),
					array(
						'id' => 'mts_accepted_payment_method_image',
						'type' => 'upload',
						'title' => __('Custom Image (Recommended size: 32x20px)', 'wooshop'),
						'sub_desc' => __('Use this option if you want to use custom image insteady of pre-defined icons.', 'wooshop'),
					),
				),
				'std' => array(
					'1' => array(
						'group_title' => '',
						'group_sort' => '1',
						'mts_accepted_payment_method_title' => 'Visa',
						'mts_accepted_payment_method_icon' => 'cc-visa',
						'mts_accepted_payment_method_image' => ''
					),
					'2' => array(
						'group_title' => '',
						'group_sort' => '2',
						'mts_accepted_payment_method_title' => 'Diners',
						'mts_accepted_payment_method_icon' => 'cc-diners-club',
						'mts_accepted_payment_method_image' => ''
					),
					'3' => array(
						'group_title' => '',
						'group_sort' => '3',
						'mts_accepted_payment_method_title' => 'Discover',
						'mts_accepted_payment_method_icon' => 'cc-discover',
						'mts_accepted_payment_method_image' => ''
					),
					'4' => array(
						'group_title' => '',
						'group_sort' => '1',
						'mts_accepted_payment_method_title' => 'MasterCard',
						'mts_accepted_payment_method_icon' => 'cc-mastercard',
						'mts_accepted_payment_method_image' => ''
					)
				)
			),
		)
	);
	$sections[] = array(
		'icon' => 'fa fa-home',
		'title' => __('Homepage', 'wooshop' ),
		'desc' => '<p class="description">' . __('From here, you can control the elements of the homepage.', 'wooshop' ) . '</p>',
		'fields' => array(
			array(
				'id' => 'mts_featured_slider',
				'type' => 'button_set_hide_below',
				'title' => __('Homepage Slider', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => wp_kses( __('<strong>Enable or Disable</strong> homepage slider with this button. The slider will show recent articles from the selected categories.', 'wooshop' ), array( 'strong' => array() ) ),
				'std' => '0',
				'args' => array('hide' => 1)
			),
			array(
				'id' => 'mts_custom_slider',
				'type' => 'group',
				'title' => __('Custom Slider', 'wooshop' ),
				'sub_desc' => __('With this option you can set up a slider with custom image and text instead of the default slider automatically generated from your posts.', 'wooshop' ),
				'groupname' => __('Slide', 'wooshop' ), // Single item name
				'subfields' => array(
					array(
						'id' => 'mts_custom_slider_image',
						'type' => 'upload',
						'title' => __('Image', 'wooshop' ),
						'sub_desc' => __('Upload or select an image for this slide', 'wooshop' ),
						'return' => 'id'
					),
					array(
						'id' => 'mts_custom_slider_title',
						'type' => 'text',
						'title' => __('Special Offer Text', 'wooshop' ),
						'sub_desc' => __('Add special offer text here.', 'wooshop' ),
					),
					array(
						'id' => 'mts_custom_slider_title_color',
						'type' => 'color',
						'title' => __('Sepcial Offer Text Color', 'wooshop' ),
						'sub_desc' => __('Set text color for special offer title.', 'wooshop' ),
						'std' => '#ffffff'
					),
					array(
						'id' => 'mts_custom_slider_heading',
						'type' => 'text',
						'title' => __('Discount or Saving Text', 'wooshop'), 
						'sub_desc' => __('Add discount or saving offer text here.', 'wooshop' ),
					),
					array(
						'id' => 'mts_custom_slider_heading_color',
						'type' => 'color',
						'title' => __('Discount or Saving Text Color', 'wooshop' ),
						'sub_desc' => __('Set text color discount or saving title.', 'wooshop' ),
						'std' => '#ffffff'
					),
					array(
						'id' => 'mts_custom_slider_heading_bg',
						'type' => 'color',
						'title' => __('Discount or Saving Text Background', 'wooshop' ),
						'sub_desc' => __('Set text background color discount or saving title.', 'wooshop' ),
						'std' => '#f2a595'
					),
					array(
						'id' => 'mts_custom_slider_subheading',
						'type' => 'text',
						'title' => __('Short Description Text', 'wooshop' ), 
						'sub_desc' => __('Add short description text here.', 'wooshop' ),
					),
					array(
						'id' => 'mts_custom_slider_subheading_color',
						'type' => 'color',
						'title' => __('Short Description Text Color', 'wooshop' ),
						'sub_desc' => __('Set text color short description text.', 'wooshop' ),
						'std' => '#5e5c5f'
					),
					array(
						'id' => 'mts_custom_slider_button',
						'type' => 'text',
						'title' => __('Button Text', 'wooshop' ), 
						'sub_desc' => __('Add button text of the slide here.', 'wooshop' ),
					),
					array(
						'id' => 'mts_custom_slider_button_color',
						'type' => 'color',
						'title' => __('Button Text Color', 'wooshop' ),
						'sub_desc' => __('Set text color for slide button.', 'wooshop' ),
						'std' => '#ffffff'
					),
					array(
						'id' => 'mts_custom_slider_button_bg',
						'type' => 'color',
						'title' => __('Button Background Color', 'wooshop' ),
						'sub_desc' => __('Set background color for slide button.', 'wooshop' ),
						'std' => '#2d2a32'
					),
					array('id' => 'mts_custom_slider_link',
						'type' => 'text',
						'title' => __('Link', 'wooshop' ),
						'sub_desc' => __('Add button URL here.', 'wooshop' ),
						'std' => '#'
					),
				),
			),
			array(
				'id' => 'mts_call_to_action',
				'type' => 'button_set_hide_below',
				'title' => __('Call to Action Bar', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => wp_kses( __('<strong>Enable or Disable</strong> Call to Action </strong> with this button.', 'wooshop' ), array( 'strong' => array() ) ),
				'std' => '1',
				'args' => array('hide' => 6)
			),
			array(
				'id' => 'mts_call_to_action_bg',
				'type' => 'background',
				'title' => __('Call to Action Background', 'wooshop' ),
				'sub_desc' => __('Set background color/pattern/custom image for call to action bar..', 'wooshop' ),
				'options' => array(
					'color'		 => '',
					'image_pattern' => $mts_patterns,
					'image_upload'  => '',
					'repeat'		=> array(),
					'attachment'	=> array(),
					'position'	  => array(),
					'size'		  => array(),
					'gradient'	  => '',
					'parallax'	  => array(),
				),
				'std' => array(
					'color'		 => '#f1f4f1',
					'use'		 	=> 'pattern',
					'image_pattern' => 'nobg',
					'image_upload'  => '',
					'repeat'		=> 'repeat',
					'attachment'	=> 'scroll',
					'position'	  => 'left top',
					'size'		  => 'cover',
					'gradient'	  => array('from' => '#ffffff', 'to' => '#000000', 'direction' => 'horizontal' ),
					'parallax'	  => '0',
				)
			),
			array(
				'id' => 'mts_call_to_action_text',
				'type' => 'text',
				'title' => __('Call to Action Text', 'wooshop' ),
				'sub_desc' => __('Add text which appears in call to action bar.', 'wooshop' ),
				'std'=> 'Want to receive <b>Special Discounts</b> and <b>New Products Alerts?</b>'
			),
			array(
				'id' => 'mts_call_to_action_text_color',
				'type' => 'color',
				'title' => __('Call to Action Text Color', 'wooshop' ),
				'sub_desc' => __('Set text color for call to action bar.', 'wooshop' ),
				'std' => '#4c4a4f'
			),
			array(
				'id' => 'mts_call_to_action_button_text',
				'type' => 'text',
				'title' => __('Call to Action Button Text', 'wooshop' ),
				'sub_desc' => __('Add button text here.', 'wooshop' ),
				'std' => 'Shop Now!',
			),
			array(
				'id' => 'mts_call_to_action_button_color',
				'type' => 'color',
				'title' => __('Call to Action Button Color', 'wooshop' ),
				'sub_desc' => __('Set button background color for call to action bar.', 'wooshop' ),
				'std' => '#ffb600'
			),
			array(
				'id' => 'mts_call_to_action_button_link',
				'type' => 'text',
				'title' => __('Call to Action Button URL', 'wooshop' ),
				'sub_desc' => __('Add button URL here.', 'wooshop' ),
				'std' => '#'
			),
			array(
				'id' => 'mts_quare_banners',
				'type' => 'button_set_hide_below',
				'title' => __('Square Banner Images', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => __('Use this option to enable suqare banner images on the homepage.', 'wooshop' ),
				'std' => '1',
				'args' => array('hide' => 2)
			),
			array(
				'id' => 'mts_quare_banners_layout',
				'type' => 'button_set',
				'title' => __('Square Banner Columns', 'wooshop' ),
				'options' => array('col-3' => __('3 Column', 'wooshop' ), 'col-4' => __('4 Column', 'wooshop' ), 'col-full' => __('Full Width', 'wooshop' )),
				'sub_desc' => __('Choose number of columns for square banner images.', 'wooshop' ),
				'std' => 'col-4',
				'class' => 'green'
			),
			array(
				'id' => 'mts_quare_banner_images',
				'title' => __('Square Banner Images', 'wooshop'), 
				'sub_desc' => __( 'Add Square Banner Images', 'wooshop' ),
				'type' => 'group',
				'groupname' => __('Banner Image', 'wooshop'), // Group name
				'subfields' => array(
					array(
						'id' => 'mts_square_banner_title',
						'type' => 'text',
						'title' => __('Title', 'wooshop'),
						'sub_desc' => __( 'This text will not be used anywhere.', 'wooshop' ),
					),
					array(
						'id' => 'mts_square_banner_image',
						'type' => 'upload',
						'title' => __('Image', 'wooshop'),
						'sub_desc' => __( 'Recommended Widths: 3 Column - 248px, 4 Column - 184px, Full Width - 796px', 'wooshop' ),
						'return' => 'url'
					),
					array(
						'id' => 'mts_square_banner_link',
						'type' => 'text',
						'title' => __('URL', 'wooshop'),
						'std' => '#'
					),
					array(
						'id' => 'mts_square_banner_text',
						'type' => 'text',
						'title' => __('Text(optional)', 'wooshop'),
						'sub_desc' => __( 'This text will appear on banner image.', 'wooshop' ),
					),
					array(
						'id' => 'mts_square_banner_text_color',
						'type' => 'color',
						'title' => __('Text Color', 'wooshop' ),
						'std' => '#ffffff'
					),
					array(
						'id' => 'mts_square_banner_text_bg',
						'type' => 'color',
						'title' => __('Text Background', 'wooshop' ),
						'std' => '#f2a595'
					),
				),
			),
		)
	);
	$sections[] = array(
		'icon' => 'fa fa-shopping-cart',
		'title' => __('WooCommerce', 'wooshop') ,
		'desc' => '<p class="description">' . __('From here, you can control your WooCommerce Shop ( WooCommerce plugin must be enabled ).', 'wooshop') . '</p>',
		'fields' => array(
			array(
				'id' => 'mts_shop_layout',
				'type' => 'radio_img',
				'title' => __('WooCommerce Page Layout Style', 'wooshop' ),
				'sub_desc' => wp_kses( __('Choose the <strong>default sidebar position</strong> for your WooCommerce pages.', 'wooshop' ), array( 'strong' => array() ) ),
				'options' => array(
					'sclayout' => array('img' => NHP_OPTIONS_URL.'img/layouts/sc.png'),
					'cslayout' => array('img' => NHP_OPTIONS_URL.'img/layouts/cs.png')
				),
				'std' => 'sclayout'
			),
			array(
				'id' => 'mts_shop_products',
				'type' => 'text',
				'title' => __('No. of Products on Shop Page', 'wooshop'),
				'sub_desc' => __('Enter the total number of products which you want to show on shop page.', 'wooshop'),
				'validate' => 'numeric',
				'std' => '16',
				'class' => 'small-text'
			),
			array(
				'id' => 'mts_single_product_slider',
				'type' => 'button_set',
				'title' => __('Single Product Image Slider', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => __('Enable or disable slider on single product images.', 'wooshop' ),
				'std' => '0'
			),
			array(
				'id'	 => 'mts_single_product_tabs',
				'type'	 => 'layout',
				'title'	=> __('Single Product Tabs', 'wooshop' ),
				'sub_desc' => __('Organize how you want tabs to appear on single product', 'wooshop' ),
				'options'  => array(
					'enabled'  => array(
						'description'	 => __('Description', 'wooshop' ),
						'additional_information'   => __('Additional Information', 'wooshop' ),
						'reviews'   => __('Reviews', 'wooshop' ),
					),
					'disabled' => array(
						
					)
				),
				'std'  => array(
					'enabled'  => array(
						'description'	 => __('Description', 'wooshop' ),
						'additional_information'   => __('Additional Information', 'wooshop' ),
						'reviews'   => __('Reviews', 'wooshop' ),
					),
					'disabled' => array(
						
					)
				)
			),
			array(
				'id' => 'mts_single_product_meta',
				'type' => 'button_set',
				'title' => __('Show Single Product Category', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => __('Use this option to show or hide category on single product page. It will appear after Add to Cart button.', 'wooshop' ),
				'std' => '0'
			),
			array(
				'id' => 'mts_single_product_rating',
				'type' => 'button_set',
				'title' => __('Show Single Product Rating', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => __('Use this option to show or hide star ratings below single product title.', 'wooshop' ),
				'std' => '1'
			),
			array(
				'id' => 'mts_wishlist',
				'type' => 'button_set',
				'title' => __('Wishlist Feature', 'wooshop'), 
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => __('Enable or disable wishlist feature. Page with "Wishlist" title and "Wishlist Page" template is required.', 'wooshop'),
				'std' => '1'
			),
			array(
				'id' => 'mts_mark_new_products',
				'type' => 'button_set_hide_below',
				'title' => __('Mark New Products', 'wooshop') ,
				'options' => array(
					'0' => 'Off',
					'1' => 'On'
				),
				'sub_desc' => __('Enable or disable "new" marking on latest products.', 'wooshop'),
				'std' => '0',
			),
			array(
				'id' => 'mts_new_products_time',
				'type' => 'text',
				'title' => __('No. of days the product is considered new', 'wooshop'),
				'sub_desc' => __('No. of days the product is considered new.', 'wooshop'),
				'validate' => 'numeric',
				'std' => '30',
				'class' => 'small-text'
			),
			array(
				'id' => 'mts_shop_pagenavigation_type',
				'type' => 'radio',
				'title' => __('Pagination Type', 'wooshop'),
				'sub_desc' => __('Select pagination type.', 'wooshop'),
				'options' => array(
					'0' => __('Numbered (1 2 3 4...)','wooshop'),
					'1' => 'AJAX (Load More Button)',
					'2' => 'AJAX (Auto Infinite Scroll)'),
				'std' => '2'
			),
			array(
				'id' => 'mts_category_ad_widgets_enabled',
				'type' => 'button_set_hide_below',
				'title' => __('Product Category Ad Widgets', 'wooshop') ,
				'options' => array(
					'0' => __('Single', 'wooshop'),
					'1' => __('Per Category', 'wooshop'),
				) ,
				'sub_desc' => __('Create separate ad widget areas (appears above the products listing) for each product category with this option.', 'wooshop'),
				'std' => '0',
				'class' => 'green',
				'args' => array('hide' => 1)
			),
			array(
				'id' => 'mts_category_ad_widgets',
				'type' => 'product_cat_multi_checkbox',
				'title' => __('Create Category Ad Widget Areas', 'wooshop'),
				'sub_desc' => __('Create Ad Widgets for archive pages of Product Categories. These widgets can be used to show promotional banners.', 'wooshop'),
				'options' => array(),
				'std' => array()
			),
			array(
				'id' => 'mts_global_size_chart_popup',
				'type' => 'select',
				'title' => __('All Products Size Chart Popup', 'wooshop' ),
				'sub_desc' => __('Select size chart popup for all products. Popup can be overridden on per category and/or product basis', 'wooshop' ),
				'options' => mts_get_size_chart_popups_options_array()
			),
		),
	);
	$sections[] = array(
		'icon' => 'fa fa-th-list',
		'title' => __('Blog Page', 'wooshop' ),
		'desc' => '<p class="description">' . __('From here, you can control the elements of the blogpage.', 'wooshop' ) . '</p>',
		'fields' => array(
			array(
				'id' => 'mts_blog_featured_slider',
				'type' => 'button_set_hide_below',
				'title' => __('Blog Slider', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => wp_kses( __('<strong>Enable or Disable</strong> blogpage slider with this button. The slider will show recent articles from the selected categories.', 'wooshop' ), array( 'strong' => array() ) ),
				'std' => '0',
				'args' => array('hide' => 3)
			),
			array(
				'id' => 'mts_featured_slider_cat',
				'type' => 'cats_multi_select',
				'title' => __('Slider Category(s)', 'wooshop' ),
				'sub_desc' => wp_kses( __('Select a category from the drop-down menu, latest articles from this category will be shown <strong>in the slider</strong>.', 'wooshop' ), array( 'strong' => array() ) ),
			),
			array(
				'id' => 'mts_featured_slider_num',
				'type' => 'text',
				'class' => 'small-text',
				'title' => __('Number of posts', 'wooshop' ),
				'sub_desc' => __('Enter the number of posts to show in the slider', 'wooshop' ),
				'std' => '3',
				'args' => array('type' => 'number')
			),	
			array(
				'id' => 'mts_blog_custom_slider',
				'type' => 'group',
				'title' => __('Custom Slider', 'wooshop' ),
				'sub_desc' => __('With this option you can set up a slider with custom image and text instead of the default slider automatically generated from your posts.', 'wooshop' ),
				'groupname' => __('Slide', 'wooshop' ), // Group name
				'subfields' => 
				array(
					array(
						'id' => 'mts_blog_custom_slider_title',
						'type' => 'text',
						'title' => __('Title', 'wooshop' ),
						'sub_desc' => __('Add title of the slide', 'wooshop' ),
					),
					array(
						'id' => 'mts_blog_custom_slider_image',
						'type' => 'upload',
						'title' => __('Image', 'wooshop' ),
						'sub_desc' => __('Upload or select an image for this slide', 'wooshop' ),
						'return' => 'id'
					),	
					array('id' => 'mts_blog_custom_slider_text',
						'type' => 'textarea',
						'title' => __('Text', 'wooshop' ),
						'sub_desc' => __('Add description of the slide', 'wooshop' ),
					), 
					array('id' => 'mts_blog_custom_slider_link',
						'type' => 'text',
						'title' => __('Link', 'wooshop' ),
						'sub_desc' => __('Insert a URL for the slide', 'wooshop' ),
						'std' => '#'
					),
				),
			),
			array(
				'id' => 'mts_featured_categories',
				'type' => 'group',
				'title'	 => __('Featured Categories', 'wooshop' ),
				'sub_desc'  => __('Select categories appearing on the homepage.', 'wooshop' ),
				'groupname' => __('Section', 'wooshop' ), // Group name
				'subfields' => array(
					array(
						'id' => 'mts_featured_category',
						'type' => 'cats_select',
						'title' => __('Category', 'wooshop' ),
						'sub_desc' => __('Select a category or the latest posts for this section', 'wooshop' ),
						'std' => 'latest',
						'args' => array('include_latest' => 1, 'hide_empty' => 0),
					),
					array(
						'id' => 'mts_featured_category_postsnum',
						'type' => 'text',
						'class' => 'small-text',
						'title' => __('Number of posts', 'wooshop' ),
						'sub_desc' => __('Enter the number of posts to show in this section.', 'wooshop' ),
						'std' => '3',
						'args' => array('type' => 'number')
					),
				),
				'std' => array(
					'1' => array(
						'group_title' => '',
						'group_sort' => '1',
						'mts_featured_category' => 'latest',
						'mts_featured_category_postsnum' => get_option('posts_per_page')
					)
				)
			),
			array(
				'id' => 'mts_post_format_icons',
				'type' => 'button_set',
				'title' => __('Post Format Icons', 'wooshop' ), 
				'sub_desc' => __('Show post format icons on the blog page.', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'std' => '1'
			),
			array(
				'id'	 => 'mts_home_headline_meta_info',
				'type'	 => 'layout',
				'title'	=> __('HomePage Post Meta Info', 'wooshop' ),
				'sub_desc' => __('Organize how you want the post meta info to appear on the homepage', 'wooshop' ),
				'options'  => array(
					'enabled'  => array(
						'date'	 => __('Date', 'wooshop' ),
						'author'   => __('Author Name', 'wooshop' ),
					),
					'disabled' => array(
						'category' => __('Categories', 'wooshop' ),
						'comment'  => __('Comment Count', 'wooshop' )
					)
				),
				'std'  => array(
					'enabled'  => array(
						'date'	 => __('Date', 'wooshop' ),
						'author'   => __('Author Name', 'wooshop' ),
					),
					'disabled' => array(
						'category' => __('Categories', 'wooshop' ),
						'comment'  => __('Comment Count', 'wooshop' )
					)
				)
			),
		)
	);
	$sections[] = array(
		'icon' => 'fa fa-file-text',
		'title' => __('Single Posts', 'wooshop' ),
		'desc' => '<p class="description">' . __('From here, you can control the appearance and functionality of your single posts page.', 'wooshop' ) . '</p>',
		'fields' => array(
			array(
				'id'	 => 'mts_single_post_layout',
				'type'	 => 'layout2',
				'title'	=> __('Single Post Layout', 'wooshop' ),
				'sub_desc' => __('Customize the look of single posts', 'wooshop' ),
				'options'  => array(
					'enabled'  => array(
						'content'   => array(
							'label' 	=> __('Post Content', 'wooshop' ),
							'subfields'	=> array(		
								array(
									'id' => 'mts_single_featured_image',
									'type' => 'button_set',
									'title' => __('Featured Image', 'wooshop' ),
									'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
									'sub_desc' => __('Use this option to show or hide the featured image in single post pages.', 'wooshop' ),
									'std' => '1'
								),
							)
						),
						'related'   => array(
							'label' 	=> __('Related Posts', 'wooshop' ),
							'subfields'	=> array(
								array(
									'id' => 'mts_related_posts_taxonomy',
									'type' => 'button_set',
									'title' => __('Related Posts Taxonomy', 'wooshop' ) ,
									'options' => array(
										'tags' => __( 'Tags', 'wooshop' ),
										'categories' => __( 'Categories', 'wooshop' )
									) ,
									'class' => 'green',
									'sub_desc' => __('Related Posts based on tags or categories.', 'wooshop' ) ,
									'std' => 'categories'
								),
								array(
									'id' => 'mts_related_postsnum',
									'type' => 'text',
									'class' => 'small-text',
									'title' => __('Number of related posts', 'wooshop' ) ,
									'sub_desc' => __('Enter the number of posts to show in the related posts section.', 'wooshop' ) ,
									'std' => '2',
									'args' => array(
										'type' => 'number'
									)
								),

							)
						),
						'author'   => array(
							'label' 	=> __('Author Box', 'wooshop' ),
							'subfields'	=> array()
						),
					),
					'disabled' => array(
						'tags'   => array(
							'label' 	=> __('Tags', 'wooshop' ),
							'subfields'	=> array()
						),
					)
				)
			),
			array(
				'id'	 => 'mts_single_headline_meta_info',
				'type'	 => 'layout',
				'title'	=> __('Meta Info to Show', 'wooshop' ),
				'sub_desc' => __('Organize how you want the post meta info to appear', 'wooshop' ),
				'options'  => array(
					'enabled'  => array(
						'date' => __('Date', 'wooshop' ),
						'author' => __('Author Name', 'wooshop' )
					),
					'disabled' => array(
						'category' => __('Categories', 'wooshop' ),
						'comment'  => __('Comment Count', 'wooshop' )
					)
				),
				'std'  => array(
					'enabled'  => array(
						'date' => __('Date', 'wooshop' ),
						'author'   => __('Author Name', 'wooshop' )
					),
					'disabled' => array(
						'category' => __('Categories', 'wooshop' ),
						'comment'  => __('Comment Count', 'wooshop' )
					)
				)
			),
			array(
				'id' => 'mts_breadcrumb',
				'type' => 'button_set',
				'title' => __('Breadcrumbs', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => __('Breadcrumbs are a great way to make your site more user-friendly. You can enable them by checking this box.', 'wooshop' ),
				'std' => '1'
			),
			array(
				'id' => 'mts_author_comment',
				'type' => 'button_set',
				'title' => __('Highlight Author Comment', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => __('Use this button to highlight author comments.', 'wooshop' ),
				'std' => '1'
			),
			array(
				'id' => 'mts_comment_date',
				'type' => 'button_set',
				'title' => __('Date in Comments', 'wooshop' ),
				'options' => array( '0' => __( 'Off', 'wooshop' ), '1' => __( 'On', 'wooshop' ) ),
				'sub_desc' => __('Use this button to show the date for comments.', 'wooshop' ),
				'std' => '1'
			),
		)
	);
	$sections[] = array(
		'icon' => 'fa fa-group',
		'title' => __('Social Buttons', 'wooshop' ),
		'desc' => '<p class="description">' . __('Enable or disable social sharing buttons on single posts using these buttons.', 'wooshop' ) . '</p>',
		'fields' => array(
			array(
				'id' => 'mts_social_button_position',
				'type' => 'button_set',
				'title' => __('Social Sharing Buttons Position', 'wooshop' ),
				'options' => array('top' => __('Above Content', 'wooshop' ), 'bottom' => __('Below Content', 'wooshop' ), 'floating' => __('Floating', 'wooshop' )),
				'sub_desc' => __('Choose position for Social Sharing Buttons.', 'wooshop' ),
				'std' => 'floating',
				'class' => 'green'
			),
			array(
				'id' => 'mts_social_buttons_on_pages',
				'type' => 'button_set',
				'title' => __('Social Sharing Buttons on Pages', 'wooshop' ),
				'options' => array('0' => __('Off', 'wooshop' ), '1' => __('On', 'wooshop' )),
				'sub_desc' => __('Enable the sharing buttons for pages too, not just posts.', 'wooshop' ),
				'std' => '0',
			),
			array(
				'id'   => 'mts_social_buttons',
				'type' => 'layout',
				'title'	=> __('Social Media Buttons', 'wooshop' ),
				'sub_desc' => __('Organize how you want the social sharing buttons to appear on single posts', 'wooshop' ),
				'options'  => array(
					'enabled'  => array(
						'facebookshare'   => __('Facebook Share', 'wooshop' ),
						'facebook'  => __('Facebook Like', 'wooshop' ),
						'twitter'   => __('Twitter', 'wooshop' ),
						'gplus' => __('Google Plus', 'wooshop' ),
						'pinterest' => __('Pinterest', 'wooshop' ),
					),
					'disabled' => array(
						'linkedin'  => __('LinkedIn', 'wooshop' ),
						'stumble'   => __('StumbleUpon', 'wooshop' ),
					)
				),
				'std'  => array(
					'enabled'  => array(
						'facebookshare'   => __('Facebook Share', 'wooshop' ),
						'facebook'  => __('Facebook Like', 'wooshop' ),
						'twitter'   => __('Twitter', 'wooshop' ),
						'gplus' => __('Google Plus', 'wooshop' ),
						'pinterest' => __('Pinterest', 'wooshop' ),
					),
					'disabled' => array(
						'linkedin'  => __('LinkedIn', 'wooshop' ),
						'stumble'   => __('StumbleUpon', 'wooshop' ),
					)
				)
			),
		)
	);
	$sections[] = array(
		'icon' => 'fa fa-bar-chart-o',
		'title' => __('Ad Management', 'wooshop' ),
		'desc' => '<p class="description">' . __('Now, ad management is easy with our options panel. You can control everything from here, without using separate plugins.', 'wooshop' ) . '</p>',
		'fields' => array(
			array(
				'id' => 'mts_posttop_adcode',
				'type' => 'textarea',
				'title' => __('Below Post Title', 'wooshop' ),
				'sub_desc' => __('Paste your Adsense, BSA or other ad code here to show ads below your article title on single posts.', 'wooshop' )
			),
			array(
				'id' => 'mts_posttop_adcode_time',
				'type' => 'text',
				'title' => __('Show After X Days', 'wooshop' ),
				'sub_desc' => __('Enter the number of days after which you want to show the Below Post Title Ad. Enter 0 to disable this feature.', 'wooshop' ),
				'validate' => 'numeric',
				'std' => '0',
				'class' => 'small-text',
				'args' => array('type' => 'number')
			),
			array(
				'id' => 'mts_postend_adcode',
				'type' => 'textarea',
				'title' => __('Below Post Content', 'wooshop' ),
				'sub_desc' => __('Paste your Adsense, BSA or other ad code here to show ads below the post content on single posts.', 'wooshop' )
			),
			array(
				'id' => 'mts_postend_adcode_time',
				'type' => 'text',
				'title' => __('Show After X Days', 'wooshop' ),
				'sub_desc' => __('Enter the number of days after which you want to show the Below Post Title Ad. Enter 0 to disable this feature.', 'wooshop' ),
				'validate' => 'numeric',
				'std' => '0',
				'class' => 'small-text',
				'args' => array('type' => 'number')
			),
		)
	);
	$sections[] = array(
		'icon' => 'fa fa-columns',
		'title' => __('Sidebars', 'wooshop' ),
		'desc' => '<p class="description">' . __('Now you have full control over the sidebars. Here you can manage sidebars and select one for each section of your site, or select a custom sidebar on a per-post basis in the post editor.', 'wooshop' ) . '<br></p>',
		'fields' => array(
			array(
				'id' => 'mts_custom_sidebars',
				'type'  => 'group', //doesn't need to be called for callback fields
				'title' => __('Custom Sidebars', 'wooshop' ),
				'sub_desc'  => wp_kses( __('Add custom sidebars. <strong style="font-weight: 800;">You need to save the changes to use the sidebars in the dropdowns below.</strong><br />You can add content to the sidebars in Appearance &gt; Widgets.', 'wooshop' ), array( 'strong' => array(), 'br' => array() ) ),
				'groupname' => __('Sidebar', 'wooshop' ), // Group name
				'subfields' => array(
					array(
						'id' => 'mts_custom_sidebar_name',
						'type' => 'text',
						'title' => __('Name', 'wooshop' ),
						'sub_desc' => __('Example: Homepage Sidebar', 'wooshop' )
					),	
					array(
						'id' => 'mts_custom_sidebar_id',
						'type' => 'text',
						'title' => __('ID', 'wooshop' ),
						'sub_desc' => __('Enter a unique ID for the sidebar. Use only alphanumeric characters, underscores (_) and dashes (-), eg. "sidebar-home"', 'wooshop' ),
						'std' => 'sidebar-'
					),
				),
			),
			array(
				'id' => 'mts_sidebar_for_home',
				'type' => 'sidebars_select',
				'title' => __('Homepage', 'wooshop' ),
				'sub_desc' => __('Select a sidebar for the homepage.', 'wooshop' ),
				'args' => array('allow_nosidebar' => false, 'exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-second', 'footer-second-2', 'footer-second-3', 'footer-second-4', 'widget-header','shop-sidebar', 'product-sidebar', 'catalog-ads')),
				'std' => 'homepage-sidebar'
			),
			array(
				'id' => 'mts_sidebar_for_post',
				'type' => 'sidebars_select',
				'title' => __('Single Post', 'wooshop' ),
				'sub_desc' => __('Select a sidebar for the single posts. If a post has a custom sidebar set, it will override this.', 'wooshop' ),
				'args' => array('exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-second', 'footer-second-2', 'footer-second-3', 'footer-second-4', 'widget-header','shop-sidebar', 'product-sidebar', 'homepage-sidebar', 'catalog-ads')),
				'std' => ''
			),
			array(
				'id' => 'mts_sidebar_for_page',
				'type' => 'sidebars_select',
				'title' => __('Single Page', 'wooshop' ),
				'sub_desc' => __('Select a sidebar for the single pages. If a page has a custom sidebar set, it will override this.', 'wooshop' ),
				'args' => array('exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-second', 'footer-second-2', 'footer-second-3', 'footer-second-4', 'widget-header','shop-sidebar', 'product-sidebar', 'homepage-sidebar', 'catalog-ads')),
				'std' => ''
			),
			array(
				'id' => 'mts_sidebar_for_archive',
				'type' => 'sidebars_select',
				'title' => __('Archive', 'wooshop' ),
				'sub_desc' => __('Select a sidebar for the archives. Specific archive sidebars will override this setting (see below).', 'wooshop' ),
				'args' => array('allow_nosidebar' => false, 'exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-second', 'footer-second-2', 'footer-second-3', 'footer-second-4', 'widget-header','shop-sidebar', 'product-sidebar', 'homepage-sidebar', 'catalog-ads')),
				'std' => ''
			),
			array(
				'id' => 'mts_sidebar_for_category',
				'type' => 'sidebars_select',
				'title' => __('Category Archive', 'wooshop' ),
				'sub_desc' => __('Select a sidebar for the category archives.', 'wooshop' ),
				'args' => array('allow_nosidebar' => false, 'exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-second', 'footer-second-2', 'footer-second-3', 'footer-second-4', 'widget-header','shop-sidebar', 'product-sidebar', 'homepage-sidebar', 'catalog-ads')),
				'std' => ''
			),
			array(
				'id' => 'mts_sidebar_for_tag',
				'type' => 'sidebars_select',
				'title' => __('Tag Archive', 'wooshop' ),
				'sub_desc' => __('Select a sidebar for the tag archives.', 'wooshop' ),
				'args' => array('allow_nosidebar' => false, 'exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-second', 'footer-second-2', 'footer-second-3', 'footer-second-4', 'widget-header','shop-sidebar', 'product-sidebar', 'homepage-sidebar', 'catalog-ads')),
				'std' => ''
			),
			array(
				'id' => 'mts_sidebar_for_date',
				'type' => 'sidebars_select',
				'title' => __('Date Archive', 'wooshop' ),
				'sub_desc' => __('Select a sidebar for the date archives.', 'wooshop' ),
				'args' => array('allow_nosidebar' => false, 'exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-second', 'footer-second-2', 'footer-second-3', 'footer-second-4', 'widget-header','shop-sidebar', 'product-sidebar', 'homepage-sidebar', 'catalog-ads')),
				'std' => ''
			),
			array(
				'id' => 'mts_sidebar_for_author',
				'type' => 'sidebars_select',
				'title' => __('Author Archive', 'wooshop' ),
				'sub_desc' => __('Select a sidebar for the author archives.', 'wooshop' ),
				'args' => array('allow_nosidebar' => false, 'exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-second', 'footer-second-2', 'footer-second-3', 'footer-second-4', 'widget-header','shop-sidebar', 'product-sidebar', 'homepage-sidebar', 'catalog-ads')),
				'std' => ''
			),
			array(
				'id' => 'mts_sidebar_for_search',
				'type' => 'sidebars_select',
				'title' => __('Search', 'wooshop' ),
				'sub_desc' => __('Select a sidebar for the search results.', 'wooshop' ),
				'args' => array('allow_nosidebar' => false, 'exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-second', 'footer-second-2', 'footer-second-3', 'footer-second-4', 'widget-header','shop-sidebar', 'product-sidebar', 'homepage-sidebar', 'catalog-ads')),
				'std' => ''
			),
			array(
				'id' => 'mts_sidebar_for_notfound',
				'type' => 'sidebars_select',
				'title' => __('404 Error', 'wooshop' ),
				'sub_desc' => __('Select a sidebar for the 404 Not found pages.', 'wooshop' ),
				'args' => array('allow_nosidebar' => false, 'exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-second', 'footer-second-2', 'footer-second-3', 'footer-second-4', 'widget-header','shop-sidebar', 'product-sidebar', 'homepage-sidebar', 'catalog-ads')),
				'std' => ''
			),
			array(
				'id' => 'mts_sidebar_for_shop',
				'type' => 'sidebars_select',
				'title' => __('Shop Pages', 'wooshop' ),
				'sub_desc' => wp_kses( __('Select a sidebar for Shop main page and product archive pages (WooCommerce plugin must be enabled). Default is <strong>Shop Page Sidebar</strong>.', 'wooshop' ), array( 'strong' => array() ) ),
				'args' => array('allow_nosidebar' => false, 'exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-second', 'footer-second-2', 'footer-second-3', 'footer-second-4', 'widget-header','shop-sidebar', 'product-sidebar', 'homepage-sidebar', 'catalog-ads')),
				'std' => 'shop-sidebar'
			),
			array(
				'id' => 'mts_sidebar_for_product',
				'type' => 'sidebars_select',
				'title' => __('Single Product', 'wooshop' ),
				'sub_desc' => wp_kses( __('Select a sidebar for single products (WooCommerce plugin must be enabled). Default is <strong>Single Product Sidebar</strong>.', 'wooshop' ), array( 'strong' => array() ) ),
				'args' => array('allow_nosidebar' => false, 'exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-second', 'footer-second-2', 'footer-second-3', 'footer-second-4', 'widget-header','shop-sidebar', 'product-sidebar', 'homepage-sidebar', 'catalog-ads')),
				'std' => 'product-sidebar'
			),
			array(
				'id' => 'mts_sidebar_for_cart',
				'type' => 'sidebars_select',
				'title' => __('Cart Page', 'wooshop' ),
				'sub_desc' => __('Select a sidebar for the single pages. If a page has a custom sidebar set, it will override this.', 'wooshop' ),
				'args' => array('exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-second', 'footer-second-2', 'footer-second-3', 'footer-second-4', 'widget-header','shop-sidebar', 'product-sidebar', 'homepage-sidebar', 'catalog-ads')),
				'std' => 'mts_nosidebar'
			),
			array(
				'id' => 'mts_sidebar_for_checkout',
				'type' => 'sidebars_select',
				'title' => __('Checkout Page', 'wooshop' ),
				'sub_desc' => __('Select a sidebar for the single pages. If a page has a custom sidebar set, it will override this.', 'wooshop' ),
				'args' => array('exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-second', 'footer-second-2', 'footer-second-3', 'footer-second-4', 'widget-header','shop-sidebar', 'product-sidebar', 'homepage-sidebar', 'catalog-ads')),
				'std' => 'mts_nosidebar'
			),
			array(
				'id' => 'mts_sidebar_for_wishlist',
				'type' => 'sidebars_select',
				'title' => __('Wishlist Page', 'wooshop' ),
				'sub_desc' => __('Select a sidebar for the single pages. If a page has a custom sidebar set, it will override this.', 'wooshop' ),
				'args' => array('exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-second', 'footer-second-2', 'footer-second-3', 'footer-second-4', 'widget-header','shop-sidebar', 'product-sidebar', 'homepage-sidebar', 'catalog-ads')),
				'std' => 'mts_nosidebar'
			),
		),
	);

	$sections[] = array(
		'icon' => 'fa fa-list-alt',
		'title' => __('Navigation', 'wooshop' ),
		'desc' => '<p class="description"><div class="controls">' . sprintf( __('Navigation settings can now be modified from the %s.', 'wooshop' ), '<a href="nav-menus.php"><b>' . __( 'Menus Section', 'wooshop' ) . '</b></a>' ) . '<br></div></p>'
	);

					
	$tabs = array();

	$args['presets'] = array();
	$args['show_translate'] = false;
	include('theme-presets.php');

	global $NHP_Options;
	$NHP_Options = new NHP_Options($sections, $args, $tabs);

} //function

add_action('init', 'setup_framework_options', 0);

/*
 * 
 * Custom function for the callback referenced above
 *
 */
function my_custom_field($field, $value){
	print_r($field);
	print_r($value);

}//function

/*
 * 
 * Custom function for the callback validation referenced above
 *
 */
function validate_callback_function($field, $value, $existing_value){
	
	$error = false;
	$value =  'just testing';
	$return['value'] = $value;
	if($error == true){
		$return['error'] = $field;
	}
	return $return;
	
}//function

/*--------------------------------------------------------------------
 * 
 * Default Font Settings
 *
 --------------------------------------------------------------------*/
if(function_exists('mts_register_typography')) { 
	mts_register_typography( array(
		'logo_font' => array(
			'preview_text' => __( 'Logo Font', 'wooshop' ),
			'preview_color' => 'dark',
			'font_family' => 'Oswald',
			'font_variant' => '700',
			'font_size' => '40px',
			'font_color' => '#ffb600',
			'css_selectors' => '#header #logo a'
		),
		'navigation_font' => array(
			'preview_text' => __( 'Navigation Font', 'wooshop' ),
			'preview_color' => 'dark',
			'font_family' => 'Droid Sans',
			'font_variant' => '400',
			'font_size' => '13px',
			'font_color' => '#929191',
			'css_selectors' => '.menu li, .menu li a, a#pull, #copyright-note > span, #copyright-note > span a'
		),
		'blog_title_font' => array(
			'preview_text' => __( 'Blog Article Title', 'wooshop' ),
			'preview_color' => 'light',
			'font_family' => 'Oswald',
			'font_size' => '20px',
			'font_variant' => 'normal',
			'font_color' => '#717074',
			'css_selectors' => '.latestPost .title a'
		),
		'single_title_font' => array(
			'preview_text' => __( 'Single Article Title', 'wooshop' ),
			'preview_color' => 'light',
			'font_family' => 'Oswald',
			'font_size' => '30px',
			'font_variant' => 'normal',
			'font_color' => '#58565b',
			'css_selectors' => '.single-title'
		),
		'content_font' => array(
			'preview_text' => __( 'Content Font', 'wooshop' ),
			'preview_color' => 'light',
			'font_family' => 'Droid Sans',
			'font_size' => '16px',
			'font_variant' => '400',
			'font_color' => '#7c7980',
			'css_selectors' => 'body'
		),
		'sidebar_font' => array(
			'preview_text' => __( 'Sidebar Font', 'wooshop' ),
			'preview_color' => 'light',
			'font_family' => 'Droid Sans',
			'font_variant' => '400',
			'font_size' => '14px',
			'font_color' => '#9c9b9e',
			'css_selectors' => '.sidebar .widget, .sidebar .widget li, .sidebar .widget li a, .sidebar .widget .wpt_widget_content a, .sidebar .widget .wp_review_tab_widget_content a, .sidebar .post-info'
		),
		'sidebar_post_title_font' => array(
			'preview_text' => __( 'Sidebar Widget Post Title', 'wooshop' ),
			'preview_color' => 'light',
			'font_family' => 'Oswald',
			'font_variant' => 'normal',
			'font_size' => '16px',
			'font_color' => '#717074',
			'css_selectors' => '.sidebar .widget .post-title a, .sidebar .widget .entry-title a'
		),
		'footer_font' => array(
			'preview_text' => __( 'Footer Font', 'wooshop' ),
			'preview_color' => 'dark',
			'font_family' => 'Droid Sans',
			'font_variant' => '400',
			'font_size' => '14px',
			'font_color' => '#acabad',
			'css_selectors' => '#site-footer'
		),
		'footer_post_title_font' => array(
			'preview_text' => __( 'Footer Widget Post Title', 'wooshop' ),
			'preview_color' => 'dark',
			'font_family' => 'Oswald',
			'font_variant' => 'normal',
			'font_size' => '16px',
			'font_color' => '#acabad',
			'css_selectors' => '#site-footer .widget .post-title a, #site-footer .widget .entry-title a'
		),
		'h1_headline' => array(
			'preview_text' => __( 'Content H1', 'wooshop' ),
			'preview_color' => 'light',
			'font_family' => 'Oswald',
			'font_variant' => 'normal',
			'font_size' => '38px',
			'font_color' => '#58565b',
			'css_selectors' => 'h1'
		),
		'h2_headline' => array(
			'preview_text' => __( 'Content H2', 'wooshop' ),
			'preview_color' => 'light',
			'font_family' => 'Oswald',
			'font_variant' => 'normal',
			'font_size' => '35px',
			'font_color' => '#58565b',
			'css_selectors' => 'h2'
		),
		'h3_headline' => array(
			'preview_text' => __( 'Content H3', 'wooshop' ),
			'preview_color' => 'light',
			'font_family' => 'Oswald',
			'font_variant' => 'normal',
			'font_size' => '32px',
			'font_color' => '#58565b',
			'css_selectors' => 'h3'
		),
		'h4_headline' => array(
			'preview_text' => __( 'Content H4', 'wooshop' ),
			'preview_color' => 'light',
			'font_family' => 'Oswald',
			'font_variant' => 'normal',
			'font_size' => '28px',
			'font_color' => '#58565b',
			'css_selectors' => 'h4'
		),
		'h5_headline' => array(
			'preview_text' => __( 'Content H5', 'wooshop' ),
			'preview_color' => 'light',
			'font_family' => 'Oswald',
			'font_variant' => 'normal',
			'font_size' => '24px',
			'font_color' => '#58565b',
			'css_selectors' => 'h5'
		),
		'h6_headline' => array(
			'preview_text' => __( 'Content H6', 'wooshop' ),
			'preview_color' => 'light',
			'font_family' => 'Oswald',
			'font_variant' => 'normal',
			'font_size' => '22px',
			'font_color' => '#58565b',
			'css_selectors' => 'h6'
		)
	));
}

(function( $ ) {

	'use strict';

	$(function() {

		$('select.mts-chart-popup-multi-select').select2();

		$("select.mts-chart-popup-multi-select").on("select2:select", function (evt) {
			var element = evt.params.data.element;
			var $element = $(element);

			$element.detach();
			$(this).append($element);
			$(this).trigger("change");
		});
	});

})( jQuery );

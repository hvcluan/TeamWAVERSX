jQuery( function ( $ ) {
    var table                    = $( '#mts-metabox-table' ),
        num_rows                 = table.find( 'tr' ).length - 1,
        num_cols                 = table.find( 'th' ).length - 1,
        h_table_input            = $( '#mts-table-hidden' ),
        build_row                = function () {
            var tmp_row = '<tr>';
            for ( var i = 0; i < num_cols; i++ ) {
                tmp_row += '<td><input class="mts-input-table" type="text" /></td>';
            }
            tmp_row += '<td class="mts-table-button-container"><input type="button" class="mts-add-row mts-table-button mts-table-button-add" value="+" /><input type="button" class="mts-del-row mts-table-button mts-table-button-del" value="-" /></td>';
            tmp_row += '</tr>';
            return tmp_row;
        },
        build_col                = function ( cell_id ) {
            var tmp_col_btn = '<th><input type="button" class="mts-add-col mts-table-button mts-table-button-add" value="+" /><input type="button" class="mts-del-col mts-table-button mts-table-button-del" value="-" /></th>',
                tmp_col     = '<td><input class="mts-input-table" type="text" /></td>';

            table.find( 'thead tr' ).find( 'th:eq(' + cell_id + ')' ).after( tmp_col_btn );
            table.find( 'tbody tr' ).each( function () {
                $( this ).find( 'td:eq(' + cell_id + ')' ).after( tmp_col );
            } );
        },
        remove_col               = function ( cell_id ) {
            table.find( 'thead tr' ).find( 'th:eq(' + cell_id + ')' ).remove();
            table.find( 'tbody tr' ).each( function () {
                $( this ).find( 'td:eq(' + cell_id + ')' ).remove();
            } );
        },
        create_matrix_from_table = function () {
            var tmp_matrix = [];

            table.find( 'tbody tr' ).each( function () {
                var cols   = [],
                    all_td = $( this ).find( 'td' );

                all_td.each( function () {
                    if ( !$( this ).is( '.mts-table-button-container' ) ) {
                        var tmp_value = $( this ).find( 'input' ).val();
                        cols.push( tmp_value );
                    }
                } );

                tmp_matrix.push( cols );
            } );

            h_table_input.val( JSON.stringify( tmp_matrix ) );
        };


    table
        .on( 'click', '.mts-add-row', function () {
            var this_cell = $( this ).closest( 'td' ),
                this_row  = this_cell.closest( 'tr' );

            num_rows++;
            this_row.after( build_row() );
            create_matrix_from_table();
        } )

        .on( 'click', '.mts-del-row', function () {
            if ( num_rows < 2 )
                return;

            var this_cell = $( this ).closest( 'td' ),
                this_row  = this_cell.closest( 'tr' );

            num_rows--;
            this_row.remove();
            create_matrix_from_table();
        } )

        .on( 'click', '.mts-add-col', function () {
            var this_cell = $( this ).closest( 'th' ),
                cell_id   = this_cell.index();

            num_cols++;
            build_col( cell_id );
            create_matrix_from_table();
        } )

        .on( 'click', '.mts-del-col', function () {
            if ( num_cols < 2 )
                return;
            var this_cell = $( this ).closest( 'th' ),
                cell_id   = this_cell.index();

            num_cols--;
            remove_col( cell_id );
            create_matrix_from_table();
        } )

        .on( 'keyup', 'input', function ( event ) {
            var this_input = $( event.target ),
                value      = this_input.val();
            // remove html tags
            if ( value.search( /<[^>]+>/ig ) > 0 || value.search( '<>' ) > 0 ) {
                this_input.val( value.replace( /<[^>]+>/ig, '' ).replace( '<>', '' ) );
            }
            create_matrix_from_table();
        } );
} );